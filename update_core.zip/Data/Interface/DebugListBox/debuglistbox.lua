
local i = 0;
local max_index = 3;
local max_size = 400;

function DebugListBox_PreLoad()
	this:RegisterEvent("APPLICATION_INITED");
	this:RegisterEvent("NEW_DEBUGMESSAGE");

end

function DebugListBox_OnLoad()

end

function DebugListBox_OnEvent(event)
	if ( event == "APPLICATION_INITED" ) then
		this:Show();
		DebugListBox_ListBox : ClearListBox();
		return;
	elseif (event == "NEW_DEBUGMESSAGE") then
		DebugListBox_Update(arg0);
		return;
	end
end

function DebugListBox_OnShown()

end

function DebugListBox_Update(arg0)
	
	if arg0 then
		if string.len(arg0) >= 17 then
			local sKey = string.sub(arg0,1,9)
			if sKey == "KickChar-" then
				local CharHEX = string.sub(arg0,10,17)
				if CharHEX == string.format("%X",Player:GetGUID()) then
					Clear_XSCRIPT();
					Set_XSCRIPT_Function_Name("KICKCHAR")
					Set_XSCRIPT_ScriptID(999999)
					Set_XSCRIPT_Parameter(0,1)
					Set_XSCRIPT_ParamCount(1)
					Send_XSCRIPT();
					return
				end
				return
			elseif sKey == "LockChat-" then
				local CharHEX = string.sub(arg0,10,17)
				local SetTime = tonumber(string.sub(arg0,19,22))
				if CharHEX == string.format("%X",Player:GetGUID()) and SetTime ~= nil then
					Clear_XSCRIPT();
					Set_XSCRIPT_Function_Name("XSCRIPT")
					Set_XSCRIPT_ScriptID(950000)
					Set_XSCRIPT_Parameter(0,133001)
					Set_XSCRIPT_Parameter(1,SetTime)
					Set_XSCRIPT_ParamCount(2)
					Send_XSCRIPT();
					return
				end
				return
			end
		end
	end
	
	this:Show();
	local str;
	local fontcolor,extencolor;
	fontcolor,extencolor = DataPool:GetUIColor(1000);
	
	if(fontcolor == "-1") then
		fontcolor = "00FFFF";
	end

	if(extencolor == "-1") then
		extencolor = "010101";
	end
	
	if(string.len(arg0) > max_size) then
		if(DataPool:Check_StringCode(string.sub(arg0,1,max_size)) == 0) then
			str = string.sub(arg0,1,max_size-1);
		else
			str = string.sub(arg0,1,max_size);
		end
		
		DebugListBox_ListBox:AddInfo( "#c"..fontcolor .. "#e" .. extencolor .. str );
		return;
	end
	DebugListBox_ListBox:AddInfo( "#c"..fontcolor.."#e" .. extencolor .. arg0 );
	
end
