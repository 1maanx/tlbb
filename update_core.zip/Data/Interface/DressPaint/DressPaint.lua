--DressPaint.lua

local MAX_OBJ_DISTANCE = 3.0
local DRESS_POS = -1
local g_NeedMoney = 50000
local g_ObjCared = -1

--PreLoad
function DressPaint_PreLoad()
	this:RegisterEvent("UI_COMMAND")
	this:RegisterEvent("OBJECT_CARED_EVENT")
	this:RegisterEvent("RESUME_ENCHASE_GEM")
	this:RegisterEvent("PACKAGE_ITEM_CHANGED")
	this:RegisterEvent("UNIT_MONEY")
	this:RegisterEvent("MONEYJZ_CHANGE")
end

--OnLoad
function DressPaint_OnLoad()

end

--OnEvent
function DressPaint_OnEvent(event)
	
	if event == "UI_COMMAND" and arg0 ~= nil and tonumber(arg0) == 1016001 then
		local targetId = Get_XParam_INT(0)
		ObjCaredID = DataPool : GetNPCIDByServerID( targetId )
		if ObjCaredID == -1 then
			return
		end
		DressPaint_Clear()
		DressPaint_OK:Disable()
		--DressPaint_Show:Disable()		
		this:Show()
		
		local xx = Get_XParam_INT(0);
		local objCared = DataPool:GetNPCIDByServerID(xx);
		BeginCareObject_DressPaint(objCared)
		
		DressPaint_DemandMoney:SetProperty("MoneyNumber", 0)
		local playerMoney = Player:GetData("MONEY")
		DressPaint_SelfMoney:SetProperty("MoneyNumber", playerMoney)
		local playerJZ = Player:GetData("MONEY_JZ")
		DressPaint_SelfJiaozi:SetProperty("MoneyNumber", playerJZ)		
	elseif event == "UI_COMMAND" and tonumber(arg0) == 140130 and this:IsVisible() then 
		if arg1 ~= nil then
			DressPaint_Update(tonumber(arg1),1)
		end
	elseif event == "UI_COMMAND" and tonumber(arg0) == 1016002 and this:IsVisible() then
		DressPaint_Update(Get_XParam_INT(0),1)
		PushEvent("UI_COMMAND",144002,Get_XParam_INT(1))
		
	elseif event == "OBJECT_CARED_EVENT" then
		if(arg0 ~= nil and tonumber(arg0) ~= objCared) then
			return;
		end		
		if(arg1 == "distance" and tonumber(arg2)>MAX_OBJ_DISTANCE or arg1=="destroy") then		
			this:Hide()
		end	

	elseif event == "RESUME_ENCHASE_GEM" and this:IsVisible() then		
		if(arg0~=nil and tonumber(arg0) == 96) then
			DressPaint_Resume_Equip()
		end

	elseif event == "PACKAGE_ITEM_CHANGED" and this:IsVisible() then
				
		if(arg0 ~= nil and -1 == tonumber(arg0)) then
			return;
		end
		
		if (DRESS_POS == tonumber(arg0)) then
			DressPaint_Update(tonumber(arg0), 1)
		end

	elseif (event == "UNIT_MONEY" and this:IsVisible()) then
		DressPaint_SelfMoney:SetProperty("MoneyNumber", tostring(Player:GetData("MONEY")));
	elseif (event == "MONEYJZ_CHANGE" and this:IsVisible()) then
		DressPaint_SelfJiaozi:SetProperty("MoneyNumber", tostring(Player:GetData("MONEY_JZ")));			
	end

end

function DressPaint_Update(Pos, isEquip)

	if isEquip == 1 then 
		local theAction = EnumAction(Pos, "packageitem")
		if theAction:GetID() ~= 0 then

			if PlayerPackage:IsLock(Pos) == 1 then 
				PushDebugMessage("#{SZPR_091023_16}")
				DressPaint_Clear()
				return
			end

			local EquipPoint = LifeAbility:Get_Equip_Point(Pos)
			if EquipPoint ~= 2 then
				PushDebugMessage("#{SZPR_091023_17}")
				return
			end

			DressPaint_Clear()
			
			DRESS_POS = Pos;
			LifeAbility:Lock_Packet_Item(DRESS_POS, 1)	
			DressPaint_Object:SetActionItem(theAction:GetID())
			DressPaint_DemandMoney:SetProperty("MoneyNumber", g_NeedMoney)

			DressPaint_OK:Enable();
			return
		
		else
			PushDebugMessage("#{SZPR_091023_17}")
			return
		end
	else
		PushDebugMessage("#{SZPR_091023_17}")
		return
	end
end

function DressPaint_Resume_Equip()	
	DressPaint_Clear()	
end

function DressPaint_Clear()
	if (DRESS_POS ~= -1) then		
		DressPaint_OK:Disable()
		DressPaint_Object:SetActionItem(-1)
		LifeAbility:Lock_Packet_Item(DRESS_POS, 0)
		DRESS_POS = -1
		DressPaint_DemandMoney:SetProperty("MoneyNumber", 0)
	end
end

function DressPaint_OnHiden()
	StopCareObject_DressPaint(objCared)
	DressPaint_Clear()

	this:Hide()
	return
end

------------------------------------------------------
--
--	ȷ��
--
function DressPaint_OK_Clicked()
	local selfMoney = Player:GetData("MONEY") + Player:GetData("MONEY_JZ")
	if selfMoney < g_NeedMoney then
		PushDebugMessage("#{no_money}")
		return
	end

	Clear_XSCRIPT()
	Set_XSCRIPT_Function_Name("XSCRIPT")
	Set_XSCRIPT_ScriptID(950000)
	Set_XSCRIPT_Parameter(0, 1016001)
	Set_XSCRIPT_Parameter(1, DRESS_POS)
	Set_XSCRIPT_ParamCount(2)
	Send_XSCRIPT()
end

function BeginCareObject_DressPaint(objCaredId)
	g_ObjCared = objCaredId
	this:CareObject(g_ObjCared, 1, "DressPaint")
end


function StopCareObject_DressPaint(objCaredId)
	this:CareObject(g_ObjCared, 0, "DressPaint")
	g_ObjCared = -1
end