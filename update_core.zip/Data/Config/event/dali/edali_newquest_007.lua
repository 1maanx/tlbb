--MisDescBegin
x210259_g_ScriptId = 210259
x210259_g_NextScriptId = 210273
x210259_g_Position_X=103
x210259_g_Position_Z=133
x210259_g_SceneID=2
x210259_g_AccomplishNPC_Name="L� Tam Th�t"
x210259_g_MissionId = 1406
x210259_g_MissionIdPre = 1405
x210259_g_Name	="Ti�n Long"
x210259_g_MissionKind = 13
x210259_g_MissionLevel = 4
x210259_g_MinMissionLevel = 4
x210259_g_IfMissionElite = 0
x210259_g_MissionName="Linh �an Di�u D��c"
x210259_g_MissionTarget="#{XSRW_100111_58}"
x210259_g_MissionInfo="#{XSRW_100111_16}"
x210259_g_ContinueInfo ="#{XSRW_100111_70}"
x210259_g_MissionComplete="#{XSRW_100111_17}"
x210259_g_MoneyBonus=30
x210259_g_ExpBonus = 400
x210259_g_SignPost = {x = 103, z = 133, tip = "L� Tam Th�t"}
x210259_g_RadioItemBonus={}
x210259_g_ItemBonus={{id=30001001,num=5}}
x210259_g_Custom = { {id="�� t�m ���c L� Tam Th�t",num=1} }
x210259_g_IsMissionOkFail = 0		--�����ĵ�0λ
--MisDescEnd
