--MisDescBegin
x210255_g_ScriptId = 210255
x210255_g_NextScriptId = 210256
x210255_g_Position_X=216
x210255_g_Position_Z=133
x210255_g_SceneID=2
x210255_g_AccomplishNPC_Name="B� L߽ng"
x210255_g_MissionId = 1401
x210255_g_MissionIdPre = 1400
x210255_g_Name	="Tri�u Thi�n S�"
x210255_g_MissionKind = 13
x210255_g_MissionLevel = 1
x210255_g_IfMissionElite = 0
x210255_g_MissionName="Thanh v� kh� th� nh�t"
x210255_g_MissionInfo="#{XSRW_100111_4}"
x210255_g_MissionTarget="#{XSRW_100111_55}"
x210255_g_ContinueInfo ="#{XSRW_100111_67}"
x210255_g_MissionComplete="#{XSRW_100111_5}"
x210255_g_MoneyBonus=1
x210255_g_ExpBonus = 50
x210255_g_SignPost = {x = 216, z = 135, tip = "B� L߽ng"}
x210255_g_RadioItemBonus={{id=10101000 ,num=1},{id=10102000,num=1},{id=10104000,num=1},{id=10103000,num=1}}
x210255_g_Custom	= { {id="�� t�m th�y Ph� L߽ng",num=1} }
x210255_g_IsMissionOkFail = 0		--�����ĵ�0λ
--MisDescEnd
