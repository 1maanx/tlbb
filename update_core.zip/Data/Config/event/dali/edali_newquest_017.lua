--MisDescBegin
x210277_g_ScriptId = 210277
x210277_g_NextScriptId = 210266
x210277_g_Position_X=160
x210277_g_Position_Z=156
x210277_g_SceneID=2
x210277_g_AccomplishNPC_Name="Tri�u Thi�n S�"
x210277_g_MissionId = 1416
x210277_g_MissionIdPre = 1415
x210277_g_Name	="V�n Phi�u Phi�u"
x210277_g_MissionKind = 13
x210277_g_MissionLevel = 8
x210277_g_MinMissionLevel = 8
x210277_g_IfMissionElite = 0
x210277_g_MissionName="G�p Thi�n S� l�n 3"
x210277_g_MissionTarget="#{XSRW_100111_62}"
x210277_g_MissionInfo="#{XSRW_100111_37}"
x210277_g_ContinueInfo ="#{XSRW_100111_74}"
x210277_g_MissionComplete="#{XSRW_100111_38}"
x210277_g_MoneyBonus=30
x210277_g_ExpBonus = 600
x210277_g_SignPost = {x = 160, z = 156, tip = "Tri�u Thi�n S�"}
x210277_g_RadioItemBonus={}
x210277_g_ItemBonus={}
x210277_g_Custom = { {id="�� t�m th�y Tri�u Thi�n S�",num=1} }
x210277_g_IsMissionOkFail = 0		--�����ĵ�0λ
--MisDescEnd
