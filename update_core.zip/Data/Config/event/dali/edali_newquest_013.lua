--MisDescBegin
x210275_g_ScriptId = 210275
x210275_g_NextScriptId = 210276
x210275_g_Position_X=160
x210275_g_Position_Z=156
x210275_g_SceneID=2
x210275_g_AccomplishNPC_Name="Tri�u Thi�n S�"
x210275_g_MissionId = 1412
x210275_g_MissionIdPre = 1423
x210275_g_Name	="�o�n Di�n Kh�nh"
x210275_g_MissionKind = 13
x210275_g_MissionLevel = 6
x210275_g_MinMissionLevel = 6
x210275_g_IfMissionElite = 0
x210275_g_MissionName="L�i g�p Thi�n S�"
x210275_g_MissionTarget="#{XSRW_100111_60}"
x210275_g_MissionInfo="#{XSRW_100111_28}"
x210275_g_ContinueInfo ="#{XSRW_100111_72}"
x210275_g_MissionComplete="#{XSRW_100111_29}"
x210275_g_SignPost = {x = 160, z = 156, tip = "Tri�u Thi�n S�"}
x210275_g_MoneyBonus=30
x210275_g_ExpBonus = 800
x210275_g_RadioItemBonus={}
x210275_g_ItemBonus={}
x210275_g_Custom = { {id="�� t�m th�y Tri�u Thi�n S�",num=1} }
x210275_g_IsMissionOkFail = 0		--�����ĵ�0λ
--MisDescEnd
