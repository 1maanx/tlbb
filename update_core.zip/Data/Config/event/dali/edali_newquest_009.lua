--MisDescBegin
x210274_g_ScriptId = 210274
x210274_g_NextScriptId = 210280
x210274_g_Position_X=214
x210274_g_Position_Z=284
x210274_g_SceneID=2
x210274_g_AccomplishNPC_Name="�o�n Di�n Kh�nh"
x210274_g_MissionId = 1408
x210274_g_MissionIdPre = 1407
x210274_g_Name	="Cao Th�ng T߶ng"
x210274_g_MissionKind = 13
x210274_g_MissionLevel = 5
x210274_g_MinMissionLevel = 5
x210274_g_IfMissionElite = 0
x210274_g_MissionName="��i L� Qu�i Nh�n"
x210274_g_MissionTarget="#{XSRW_100111_59}"
x210274_g_MissionInfo="#{XSRW_100111_20}"
x210274_g_ContinueInfo ="#{XSRW_100111_71}"
x210274_g_MissionComplete="#{XSRW_100111_21}"
x210274_g_MoneyBonus=100
x210274_g_ExpBonus = 800
x210274_g_SignPost = {x = 214, z = 284, tip = "�o�n Di�n Kh�nh"}
x210274_g_RadioItemBonus={}
x210274_g_ItemBonus={}
x210274_g_Custom = { {id="�� t�m ���c �o�n Di�n Kh�nh",num=1} }
x210274_g_IsMissionOkFail = 0		--�����ĵ�0λ
--MisDescEnd
