--MisDescBegin
x210279_g_ScriptId = 210279
x210279_g_Position_X=241
x210279_g_Position_Z=137
x210279_g_SceneID=2
x210279_g_AccomplishNPC_Name="Th�i Ph�ng C�u"
x210279_g_MissionId = 1422
x210279_g_Name	="Tri�u Thi�n S�"
x210279_g_MissionKind = 13
x210279_g_MissionLevel = 10
x210279_g_MinMissionLevel = 10
x210279_g_IfMissionElite = 0
x210279_g_MissionName="Giang h� r�ng l�n"
x210279_g_MissionTarget="#{XSRW_100111_64}"
x210279_g_MissionInfo="#{XSRW_100111_50}"
x210279_g_ContinueInfo ="#{XSRW_100111_76}"
x210279_g_MissionComplete="#{XSRW_100111_51}"
x210279_g_MoneyBonus=100
x210279_g_ExpBonus = 1000
x210279_g_SignPost = {x = 241, z = 137, tip = "Th�i Ph�ng C�u"}
x210279_g_RadioItemBonus={}
x210279_g_ItemBonus={}
x210279_g_Custom = { {id="�� t�m ���c Th�i Ph�ng C�u",num=1} }
x210279_g_IsMissionOkFail = 0		--�����ĵ�0λ
--MisDescEnd
