--MisDescBegin
x210268_g_ScriptId = 210268
x210268_g_NextScriptId = 210279
x210268_g_Position_X=160
x210268_g_Position_Z=157
x210268_g_SceneID=2
x210268_g_AccomplishNPC_Name="Tri�u Thi�n S�"
x210268_g_MissionId = 1421
x210268_g_MissionIdPer = 0
x210268_g_Name	="Tri�u Thi�n S�"
x210268_g_MissionKind = 13
x210268_g_MissionLevel = 10
x210268_g_IfMissionElite = 0
x210268_g_MissionName="10 m�n ph�i"
x210268_g_MissionInfo="#{XSRW_100111_48}" --��������
x210268_g_MissionTarget="#{XSRW_100111_97}"
x210268_g_ContinueInfo="#{XSRW_100111_98}"
x210268_g_MissionComplete="#{XSRW_100111_49}"
x210268_g_ItemBonus={}
x210268_g_IsMissionOkFail = 0		--�����ĵ�0λ
x210268_g_Custom	= { {id="Gia nh�p m�n ph�i",num=1} }--�����ĵ�1λ
--MisDescEnd
