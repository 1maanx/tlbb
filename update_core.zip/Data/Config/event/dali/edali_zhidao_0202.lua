--MisDescBegin
x210202_g_ScriptId = 210202
x210202_g_Position_X=110.0841
x210202_g_Position_Z=158.7671
x210202_g_SceneID=2
x210202_g_AccomplishNPC_Name="в T� Тng"
x210202_g_MissionId = 442
x210202_g_MissionIdPre = 441
x210202_g_Name	="в T� Тng"
x210202_g_ItemId = 30101001
x210202_g_ItemNeedNum = 1
x210202_g_MissionKind = 13
x210202_g_MissionLevel = 1
x210202_g_IfMissionElite = 0
x210202_g_DemandItem={{id=30101001,num=1}}		--������1λ
x210202_g_IsMissionOkFail = 1		--�����ĵ�0λ
x210202_g_MissionName="C�i b�nh bao th� nh�t"
x210202_g_MissionInfo_1="  #R"
x210202_g_MissionInfo_2="#{event_dali_0004}"
x210202_g_MissionTarget="#{xinshou_002}"
x210202_g_MissionContinue="C�c h� �� l�m #Yb�nh bao#W xong ch�a?"
x210202_g_MissionComplete="  Ch�, xem ra t�i n�ng n�u n߾ng c�a c�c h� kh�ng ch� � m�c b�nh th߶ng"
x210202_g_MoneyBonus=1
x210202_g_SignPost = {x = 110, z = 159, tip = "в T� Тng"}
x210202_g_RadioItemBonus={{id=30304030 ,num=1},{id=30304031,num=1}}
--MisDescEnd
