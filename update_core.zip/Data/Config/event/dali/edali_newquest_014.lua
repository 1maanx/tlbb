--MisDescBegin
x210276_g_ScriptId = 210276
x210276_g_NextScriptId = 210264
x210276_g_Position_X=265
x210276_g_Position_Z=128
x210276_g_SceneID=2
x210276_g_AccomplishNPC_Name="V�n Phi�u Phi�u"
x210276_g_MissionId = 1413
x210276_g_Name	="Tri�u Thi�n S�"
x210276_g_MissionKind = 13
x210276_g_MissionLevel = 7
x210276_g_MinMissionLevel = 7
x210276_g_IfMissionElite = 0
x210276_g_MissionName="Tr�n Th� gia t�c"
x210276_g_MissionTarget="#{XSRW_100111_61}"
x210276_g_MissionInfo="#{XSRW_100111_30}"
x210276_g_ContinueInfo ="#{XSRW_100111_73}"
x210276_g_MissionComplete="#{XSRW_100111_31}"
x210276_g_MoneyBonus=30
x210276_g_ExpBonus = 600
x210276_g_SignPost = {x = 265, z = 128, tip = "V�n Phi�u Phi�u"}
x210276_g_RadioItemBonus={}
x210276_g_ItemBonus={}
x210276_g_Custom = { {id="�� t�m ���c V�n Phi�u Phi�u",num=1} }
x210276_g_IsMissionOkFail = 0		--�����ĵ�0λ
--MisDescEnd
