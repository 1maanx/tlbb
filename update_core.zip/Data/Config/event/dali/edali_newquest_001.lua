--MisDescBegin
x210262_g_ScriptId = 210262
x210262_g_NextScriptId = 210255
x210262_g_Position_X = 160
x210262_g_Position_Z = 156
x210262_g_SceneID = 2
x210262_g_AccomplishNPC_Name = "Tri�u Thi�n S�"
x210262_g_MissionId = 1400
x210262_g_MissionIdPre = 0
x210262_g_Name	="Tri�u Thi�n S�"
x210262_g_MissionKind = 13
x210262_g_MissionLevel = 1
x210262_g_IfMissionElite = 0
x210262_g_MissionName = "еt ph� giang h�"
x210262_g_MissionInfo = ""
x210262_g_MissionTarget = "#{XSRW_100111_1}"
x210262_g_ContinueInfo = ""
x210262_g_MissionComplete = "#{XSRW_100111_2}"
x210262_g_MoneyBonus = 1
x210262_g_ExpBonus = 50
x210262_g_SignPost = {x = 160, z = 156, tip = "Tri�u Thi�n S�"}
x210262_g_Custom	= { {id="�� t�m th�y Tri�u Thi�n S�",num=1} }
x210262_g_IsMissionOkFail = 0		--�����ĵ�0λ
--MisDescEnd
