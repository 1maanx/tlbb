--MisDescBegin
x210256_g_ScriptId = 210256
x210256_g_NextScriptId = 210257
x210256_g_Position_X=238
x210256_g_Position_Z=171
x210256_g_SceneID=2
x210256_g_AccomplishNPC_Name="Ho�ng C�ng ��o"
x210256_g_MissionId = 1402
x210256_g_MissionIdPre = 1401
x210256_g_Name	="B� L߽ng"
x210256_g_MissionKind = 13
x210256_g_MissionLevel = 1
x210256_g_MinMissionLevel = 1
x210256_g_IfMissionElite = 0
x210256_g_MissionName="Ph�ng c� th� nh�t"
x210256_g_MissionTarget="#{XSRW_100111_56}"
x210256_g_MissionInfo="#{XSRW_100111_6}"
x210256_g_ContinueInfo ="#{XSRW_100111_68}"
x210256_g_MissionComplete="#{XSRW_100111_7}"
x210256_g_MoneyBonus=1
x210256_g_ExpBonus = 50
x210256_g_SignPost = {x = 238, z = 171, tip = "Ho�ng C�ng ��o"}
x210256_g_RadioItemBonus={}
x210256_g_ItemBonus={{id=10113000 ,num=1}}
x210256_g_Custom	= { {id="�� t�m ���c Ho�ng C�ng ��o",num=1} }
x210256_g_IsMissionOkFail = 0		--�����ĵ�0λ
--MisDescEnd
