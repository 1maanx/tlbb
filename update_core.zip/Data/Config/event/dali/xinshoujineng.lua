--MisDescBegin
x210250_g_ScriptId = 210250
x210250_g_Position_X=160.0895
x210250_g_Position_Z=156.9309
x210250_g_SceneID=2
x210250_g_AccomplishNPC_Name="Tri�u Thi�n S�"
x210250_g_MissionId = 757
x210250_g_MissionIdPre = 444
x210250_g_Name	="Tri�u Thi�n S�"
x210250_g_MissionKind = 13
x210250_g_MissionLevel = 2
x210250_g_IfMissionElite = 0
x210250_g_MissionName="#{MPZY_90416_5}"
x210250_g_MissionInfo="#{MPZY_90416_2}"
x210250_g_MissionTarget="#{MPZY_90416_1}"
x210250_g_MissionContinue="#{MPZY_90416_3}"
x210250_g_MissionComplete="#{MPZY_90416_4}" 
x210250_g_MoneyBonus=1
x210250_g_SignPost = {x = 160, z = 156, tip = "Tri�u Thi�n S�"}
x210250_g_IsMissionOkFail = 0		--�����ĵ�0λ
x210250_g_Custom	= { {id="�� h�c k� n�ng t�n th�",num=1} }
--MisDescEnd
