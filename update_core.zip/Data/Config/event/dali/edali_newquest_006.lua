--MisDescBegin
x210263_g_ScriptId = 210263
x210263_g_NextScriptId = 210259
x210263_g_Position_X = 144
x210263_g_Position_Z = 138
x210263_g_SceneID = 2
x210263_g_AccomplishNPC_Name = "Ti�n Long"
x210263_g_MissionId = 1405
x210263_g_MissionIdPre = 0
x210263_g_Name	="Ti�n Long"
x210263_g_AcceptNPC_Name="Tri�u Thi�n S�"
x210263_g_MissionKind = 13
x210263_g_MissionLevel = 3
x210263_g_IfMissionElite = 0
x210263_g_MissionName="K� n�ng s� c�p"
x210263_g_MissionInfo="#{XSRW_100111_12}"
x210263_g_MissionTarget="#{XSRW_100111_86}"
x210263_g_MissionContinue="#{XSRW_100111_94}"
x210263_g_MissionComplete="#{XSRW_100111_13}"
x210263_g_MoneyBonus=30
x210263_g_ExpBonus=400
x210263_g_SignPost = {x = 144, z = 138, tip = "Ti�n Long"}
x210263_g_IsMissionOkFail = 0		--�����ĵ�0λ
x210263_g_Custom	= { {id="H�c N�i K�nh C�ng K�ch",num=1}, {id="H�c S� C�p �n еn",num=1} }
--MisDescEnd
