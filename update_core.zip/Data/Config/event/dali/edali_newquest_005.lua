--MisDescBegin
x210258_g_ScriptId = 210258
x210258_g_NextScriptId = 210263
x210258_g_Position_X=160
x210258_g_Position_Z=156
x210258_g_SceneID=2
x210258_g_AccomplishNPC_Name="Tri�u Thi�n S�"
x210258_g_MissionId = 1404
x210258_g_MissionIdPre = 1403
x210258_g_Name	="Ho�ng C�ng ��o"
x210258_g_MissionKind = 13
x210258_g_MissionLevel = 3
x210258_g_MinMissionLevel = 3
x210258_g_IfMissionElite = 0
x210258_g_MissionName="Quay v� g�p Thi�n S�"
x210258_g_MissionTarget="#{XSRW_100111_57}"
x210258_g_MissionInfo="#{XSRW_100111_10}"
x210258_g_ContinueInfo ="#{XSRW_100111_69}"
x210258_g_MissionComplete="#{XSRW_100111_11}"
x210258_g_MoneyBonus=30
x210258_g_ExpBonus = 300
x210258_g_SignPost = {x = 160, z = 156, tip = "Tri�u Thi�n S�"}
x210258_g_RadioItemBonus={}
x210258_g_ItemBonus={}
x210258_g_Custom = { {id="�� t�m th�y Tri�u Thi�n S�",num=1} }
x210258_g_IsMissionOkFail = 0		--�����ĵ�0λ
--MisDescEnd
