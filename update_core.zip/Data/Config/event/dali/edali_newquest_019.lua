--MisDescBegin
x210278_g_ScriptId = 210278
x210278_g_NextScriptId = 210267
x210278_g_Position_X=145
x210278_g_Position_Z=138
x210278_g_SceneID=2
x210278_g_AccomplishNPC_Name="Ti�n Long"
x210278_g_MissionId = 1418
x210278_g_MissionIdPre = 1417
x210278_g_Name	="Tri�u Thi�n S�"
x210278_g_MissionKind = 13
x210278_g_MissionLevel = 8
x210278_g_MinMissionLevel = 8
x210278_g_IfMissionElite = 0
x210278_g_MissionName="��i Thi�n Nh�n"
x210278_g_MissionTarget="#{XSRW_100111_63}"
x210278_g_MissionInfo="#{XSRW_100111_41}"
x210278_g_ContinueInfo ="#{XSRW_100111_75}"
x210278_g_MissionComplete="#{XSRW_100111_42}"
x210278_g_MoneyBonus=30
x210278_g_ExpBonus = 600
x210278_g_SignPost = {x = 145, z = 138, tip = "Ti�n Long"}
x210278_g_RadioItemBonus={}
x210278_g_ItemBonus={}
x210278_g_Custom = { {id="�� t�m ���c Ti�n Long",num=1} }
x210278_g_IsMissionOkFail = 0		--�����ĵ�0λ
--MisDescEnd
