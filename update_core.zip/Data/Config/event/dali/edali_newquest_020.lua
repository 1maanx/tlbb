--MisDescBegin
x210267_g_ScriptId = 210267
x210267_g_NextScriptId = 210269
x210267_g_Position_X = 160
x210267_g_Position_Z = 158
x210267_g_SceneID = 2
x210267_g_AccomplishNPC_Name = "Tri�u Thi�n S�"
x210267_g_MissionId = 1419
x210267_g_MissionIdPre = 1418
x210267_g_Name	="Ti�n Long"
x210267_g_MissionKind = 13
x210267_g_MissionLevel = 9
x210267_g_IfMissionElite = 0
x210267_g_IsMissionOkFail = 0		--�����ĵ�0λ
x210267_g_Custom	= { {id="�� li�n t�c ��p ��ng 5 c�u h�i c�a Ti�n Long",num=1} }
x210267_g_MissionName="V�n ��p Giang H�"
x210267_g_MissionInfo="#{XSRW_100111_43}"
x210267_g_MissionTarget="#{XSRW_100111_92}"
x210267_g_ContinueInfo="#{XSRW_100111_44}"		--δ��������npc�Ի�
x210267_g_MissionComplete="#{XSRW_100111_45}"
x210267_g_MoneyBonus=100
x210267_g_ExpBonus=600
x210267_g_SignPost = {x = 145, z = 138, tip = "Ti�n Long"}
x210267_g_ItemBonus={{id=10111000,num=1}}
--MisDescEnd
