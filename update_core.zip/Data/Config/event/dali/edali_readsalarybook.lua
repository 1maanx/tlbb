--MisDescBegin
x210251_g_ScriptId = 210251
x210251_g_MissionIdPre =759
x210251_g_MissionNext = {{id=761,index=1018820},{id=762,index=1018821},{id=763,index=1018822},{id=764,index=1018823},
{id=765,index=1018824},{id=766,index=1018825},{id=767,index=1018826},{id=768,index=1018827},
{id=769,index=1018828},{id=-1,index=-1},      {id=796,index=1018845},  --newmenpai
}
x210251_g_MissionId = 760
x210251_g_Name	="Ch�c Ph�c Qu�" 
x210251_g_MissionKind = 13
x210251_g_MissionLevel = 30
x210251_g_IfMissionElite = 0
x210251_g_IsMissionOkFail = 0					--�����ĵ�0λ
x210251_g_MissionName="Thi�n Long C�ng T� c�a Thanh аng V� L�m �n"
x210251_g_MissionInfo="#{FLS_090721_7}"  
x210251_g_MissionTarget="#{FLS_090721_8}"
x210251_g_ContinueInfo= "#{FLS_090721_68}"	
x210251_g_MissionComplete="#{FLS_090721_11}"
x210251_g_Custom	= { {id="�� ��c Thi�n Long C�ng T� th�",num=1} }
--MisDescEnd
