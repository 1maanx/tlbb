--MisDescBegin
x212100_g_ScriptId = 212100
x212100_g_MissionId = 648
x212100_g_Name	="T� Phi"
x212100_g_MissionKind = 41
x212100_g_MissionLevel = 25
x212100_g_IfMissionElite = 0
x212100_g_MissionName="Th� gi�i hoa c�"
x212100_g_MissionInfo="#{Mis_K_Xihu_1000042}"
x212100_g_MissionTarget="#{MIS_TAR_ADD_010}"
x212100_g_ContinueInfo="  Ng߽i �� gi�t ch�t #RM�ch H�u Nh�n#W r�i?"
x212100_g_MissionComplete="  �a t� ng߽i, 1 th� gi�i m�i nh� ph�ng ph�t tr߾c m�t ta"
x212100_g_MoneyBonus=1800
x212100_g_exp=18000
x212100_g_Custom	= { {id="�� gi�t ch�t M�ch H�u Nh�n",num=1} }
x212100_g_IsMissionOkFail = 0
x212100_g_RadioItemBonus={{id=10412063 ,num=1},{id=10413065,num=1},{id=10402065,num=1}}
--MisDescEnd
