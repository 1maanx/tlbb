--MisDescBegin
x212132_g_ScriptId = 212132
x212132_g_Position_X=207
x212132_g_Position_Z=212
x212132_g_SceneID=0
x212132_g_AccomplishNPC_Name="T� M� Quang"
x212132_g_MissionId = 254
x212132_g_PreMissionId = 349
x212132_g_Name	="T� M� Quang"
x212132_g_MissionKind = 55
x212132_g_MissionLevel = 75
x212132_g_IfMissionElite = 0
x212132_g_MissionName="T�ch m�ch cao th�"
x212132_g_MissionInfo="#{Mis_Hero_songxin_02}"
x212132_g_MissionTarget="    T�m T� M� Quang � L�c D߽ng #{_INFOAIM207,212,0,T� M� Quang}. "
x212132_g_MissionComplete="  иa v� v� quan h� c�a c�c h� �u �� �c b� giang h�, c�ch danh hi�u anh h�ng kh�ng c�n bao xa."
x212132_g_MoneyBonus=50000
x212132_g_exp=700000
x212132_g_Custom	= { {id="�� t�m th�y T� M� Quang",num=1} }
x212132_g_IsMissionOkFail = 0
x212132_g_RadioItemBonus={{id=10510047 ,num=1},{id=10515027,num=1}}
--MisDescEnd
