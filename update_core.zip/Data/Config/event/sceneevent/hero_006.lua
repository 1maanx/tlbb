--MisDescBegin
x212133_g_ScriptId = 212133
x212133_g_Position_X=267
x212133_g_Position_Z=116
x212133_g_SceneID=1
x212133_g_AccomplishNPC_Name="V߽ng An Th�ch"
x212133_g_MissionId = 255
x212133_g_PreMissionId = 389
x212133_g_Name	="V߽ng An Th�ch"
x212133_g_MissionKind = 55
x212133_g_MissionLevel = 75
x212133_g_IfMissionElite = 0
x212133_g_MissionName="V� �ch hi�p kh�ch"
x212133_g_MissionInfo="#{Mis_Hero_songxin_03}"
x212133_g_MissionTarget="    T�m V߽ng An Th�ch � th�nh T� Ch�u #{_INFOAIM267,116,1,V߽ng An Th�ch}. "
x212133_g_MissionComplete="  V� c�ng v� danh v�ng c�a c�c h� �u �� �c b� giang h�, c�ch danh hi�u anh h�ng kh�ng c�n bao xa."
x212133_g_MoneyBonus=50000
x212133_g_exp=700000
x212133_g_Custom	= { {id="�� t�m th�y V߽ng An Th�ch",num=1} }
x212133_g_IsMissionOkFail = 0
x212133_g_RadioItemBonus={{id=10520087 ,num=1},{id=10522067,num=1}}
--MisDescEnd
