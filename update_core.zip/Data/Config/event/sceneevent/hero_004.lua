--MisDescBegin
x212131_g_ScriptId = 212131
x212131_g_Position_X=222
x212131_g_Position_Z=102
x212131_g_SceneID=2
x212131_g_AccomplishNPC_Name="Th�m Qu�t"
x212131_g_MissionId = 253
x212131_g_PreMissionId = 309
x212131_g_Name	="Th�m Qu�t"
x212131_g_MissionKind = 55
x212131_g_MissionLevel = 75
x212131_g_IfMissionElite = 0
x212131_g_MissionName="H�nh gi� v� song"
x212131_g_MissionInfo="#{Mis_Hero_songxin_01}"
x212131_g_MissionTarget="    T�m Th�m Qu�t � th�nh ��i L� #{_INFOAIM222,103,2,Th�m Qu�t}. "
x212131_g_MissionComplete="  Ki�n th�c v� kinh nghi�m c�a c�c h� �u �� �c b� giang h�, c�ch danh hi�u anh h�ng kh�ng c�n bao xa."
x212131_g_MoneyBonus=50000
x212131_g_exp=700000
x212131_g_Custom	= { {id="�� t�m th�y Th�m Qu�t",num=1} }
x212131_g_IsMissionOkFail = 0
x212131_g_RadioItemBonus={{id=10512017 ,num=1},{id=10511007,num=1}}
--MisDescEnd
