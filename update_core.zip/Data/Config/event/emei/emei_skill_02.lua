--MisDescBegin
x212117_g_ScriptId = 212117
x212117_g_Position_X=217
x212117_g_Position_Z=255
x212117_g_SceneID=2
x212117_g_AccomplishNPC_Name="V߽ng Thi�u"
x212117_g_MissionId = 923
x212117_g_PreMissionId = 922
x212117_g_Name	="V߽ng Thi�u"
x212117_g_MissionKind = 26
x212117_g_MissionLevel = 20
x212117_g_IfMissionElite = 0
x212117_g_MissionName="T�n �i�m nh�n s�"
x212117_g_MissionInfo="#{emei_skill_mis_06}"
x212117_g_MissionTarget="  Mang n�p #G5 v�ng#W giao cho th�nh ��i L� Tu V�n ��i#W cho #RV߽ng Thi�u #W#{_INFOAIM217,255,2,V߽ng Thi�u}. "
x212117_g_MissionContinue="  C�c h� quy�t �nh h�c Kim ch�m � ki�p sao?"
x212117_g_MissionComplete="#{emei_skill_mis_07}"
x212117_g_MoneyBonus=2000
x212117_g_exp=1000
x212117_g_IsMissionOkFail = 0
--MisDescEnd
