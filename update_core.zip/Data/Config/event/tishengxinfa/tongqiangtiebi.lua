--MisDescBegin
x890002_g_ScriptId = 890002
x890002_g_MissionIdPre  = 751
x890002_g_MissionId		= 752
x890002_g_MissionIdNext	= 753
x890002_g_NextScriptId	= 890003
x890002_g_MissionKind = 4
x890002_g_MissionLevel = 45
x890002_g_IfMissionElite = 0
x890002_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x890002_g_MissionName		= "#{TSXF_090408_06}"
x890002_g_MissionInfo_1		= "#{TSXF_090408_20}"
x890002_g_MissionInfo_2		= "#{TSXF_090408_21}"
x890002_g_MissionTarget		= "%f"
x890002_g_FormatList = {
"#{TSXF_090408_35}#Y%s#W#{TSXF_090408_36}#{TSXF_090408_14}#Y%s#W#{TSXF_090408_22}",
}
x890002_g_StrForePart=4
x890002_g_StrList = {
"��t Ma T�m Kinh",
"K�ch L�u ��i Ph�p",
"C�m Long C�ng",
"Th�i C�c Ki�m Ph�p",
"Th�c N� Ki�m Ph�p",
"Th�n M�c C�ng",
"�o�n Gia Quy�n Ph�p",
"Thi�n S�n Dung Tuy�t C�ng",
"�o�n Ca H�nh",
"Tu� Ph߽ng#{_INFOAIM96,82,9,Tu� Ph߽ng}",
"L�m Nham#{_INFOAIM98,105,11,L�m Nham}",
"H�ng Th�ng#{_INFOAIM92,77,10,H�ng Th�ng}",
"Tr߽ng Trung H�nh#{_INFOAIM78,95,12,Tr߽ng Trung H�nh}",
"M�nh Long#{_INFOAIM96,86,15,M�nh Long}",
"V߽ng Ng�n#{_INFOAIM96,92,16,V߽ng Ng�n}",
"B�n Ph�m#{_INFOAIM96,88,13,B�n Ph�m}",
"Ph� M�n Nghi#{_INFOAIM95,60,17,Ph� M�n Nghi}",
"T�n Quan#{_INFOAIM119,152,14,T�n Quan}",
"Thanh V�n B� T�ch",               --newmenpai
"M� Dung Th�ng#{_INFOAIM69,125,284,M� Dung Th�ng}",
}
x890002_g_ContinueInfo_1	= "#{TSXF_090408_12}"
x890002_g_ContinueInfo_2	= "#{TSXF_090408_13}"
x890002_g_MissionComplete_1	= "#{TSXF_090408_12}"
x890002_g_MissionComplete_2	= "#{TSXF_090408_33}"
x890002_g_MissionComplete_3	= "#{TSXF_090408_41}"
x890002_g_MaxRound	= 1
x890002_g_MissionXinFa	= 35	
x890002_g_Custom	= { {id="�� luy�n �n c�p 35",num=1} }
x890002_g_MoneyBonus		=	70000
x890002_g_ItemBonus={id=30505148, num=2}
--MisDescEnd
