--MisDescBegin
x890003_g_ScriptId = 890003
x890003_g_MissionIdPre  = 752
x890003_g_MissionId		= 753
x890003_g_MissionIdNext	= 754
x890003_g_NextScriptId	= 890003
x890003_g_MissionKind = 4
x890003_g_MissionLevel = 45
x890003_g_IfMissionElite = 0
x890003_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x890003_g_MissionName		= "#{TSXF_090408_07}"
x890003_g_MissionInfo_1		= "#{TSXF_090408_28}"
x890003_g_MissionInfo_2		= "#{TSXF_090408_21}"
x890003_g_MissionTarget		= "%f"
x890003_g_FormatList = {
"#{TSXF_090408_35}#Y%s#W#{TSXF_090408_36}#{TSXF_090408_14}#Y%s#W#{TSXF_090408_22}",
}
x890003_g_StrForePart=4
x890003_g_StrList = {
"Ph�p Hoa Kinh",
"Qu� Hoa B� C�p",
"иa �߶ng C�ng",
"Lo�n Ho�n Quy�t",
"Th�n H�u Kinh",
"Ng� еc C�ng",
"��i L� Binh Ph�p",
"Ti�u V� T߽ng C�ng",
"еn Gi�p Thi�n Th�",
"Tu� Ph߽ng#{_INFOAIM96,82,9,Tu� Ph߽ng}",
"L�m Nham#{_INFOAIM98,105,11,L�m Nham}",
"H�ng Th�ng#{_INFOAIM92,77,10,H�ng Th�ng}",
"Tr߽ng Trung H�nh#{_INFOAIM78,95,12,Tr߽ng Trung H�nh}",
"M�nh Long#{_INFOAIM96,86,15,M�nh Long}",
"V߽ng Ng�n#{_INFOAIM96,92,16,V߽ng Ng�n}",
"B�n Ph�m#{_INFOAIM96,88,13,B�n Ph�m}",
"Ph� M�n Nghi#{_INFOAIM95,60,17,Ph� M�n Nghi}",
"T�n Quan#{_INFOAIM119,152,14,T�n Quan}",
"S�t Tr�n Quy�t",
"M� Dung Th�ng#{_INFOAIM69,125,284,M� Dung Th�ng}", 
}
x890003_g_ContinueInfo_1	= "#{TSXF_090408_12}"
x890003_g_ContinueInfo_2	= "#{TSXF_090408_13}"
x890003_g_MissionComplete_1	= "#{TSXF_090408_12}"
x890003_g_MissionComplete_2	= "#{TSXF_090408_33}"
x890003_g_MissionComplete_3	= "#{TSXF_090408_41}"
x890003_g_MaxRound	= 1
x890003_g_MissionXinFa	= 35	
x890003_g_Custom	= { {id="�� luy�n �n c�p 35",num=1} }
x890003_g_MoneyBonus		=	70000
x890003_g_ItemBonus={id=30505148, num=2}
--MisDescEnd
