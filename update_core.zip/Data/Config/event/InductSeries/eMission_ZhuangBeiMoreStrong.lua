--MisDescBegin
x500623_g_ScriptId = 500623
x500623_g_Position_X=177.4994
x500623_g_Position_Z=184.2609
x500623_g_SceneID=0
x500623_g_AccomplishNPC_Name="B�nh Ho�i Ng�c"
x500623_g_MissionId = 1189
x500623_g_MissionIdPre = 1188
x500623_g_Name	="B�nh Ho�i Ng�c"
x500623_g_ItemNeedNum = 1
x500623_g_MissionKind = 11
x500623_g_MissionLevel = 40
x500623_g_IfMissionElite = 0
x500623_g_Custom	= { {id="Ho�n th�nh Kh�m N�m b�o th�ch",num=1} }
x500623_g_IsMissionOkFail = 1		--�����ĵ�0λ
x500623_g_MissionName="#{YDXF_XML_3}"
x500623_g_MissionTarget="#{YDXF_091229_14}"
x500623_g_SignPost = {x = 177, z = 184, tip = "B�nh Ho�i Ng�c"}
x500623_g_RadioItemBonus={{id=50201001 ,num=1},{id=50201002,num=1}}
--MisDescEnd
