--MisDescBegin
x500618_g_ScriptId	= 500618
x500618_g_Position_X=244.4806
x500618_g_Position_Z=215.3521
x500618_g_SceneID=1
x500618_g_AccomplishNPC_Name="H� Di�n B�o"
x500618_g_PreMissionId	=	470
x500618_g_MissionId			= 471
x500618_g_MissionIdNext	= 472
x500618_g_AcceptNPC_SceneID	=	1
x500618_g_MissionIndexNext	= 1018720
x500618_g_NextScriptId	= 006668
x500618_g_Name 					= "H� Di�n B�o"
x500618_g_MissionKind			= 12
x500618_g_MissionLevel		= 45
x500618_g_IfMissionElite	= 0
x500618_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x500618_g_MissionName			= "Th�i H� Thu� Tr�i"
x500618_g_MissionInfo			= "#{YD_20080421_116}"
x500618_g_MissionTarget		= "#{YD_20080421_115}"
x500618_g_ContinueInfo		= "#{YD_20080421_206}"
x500618_g_MissionComplete	= "#{YD_20080421_207}"
x500618_g_MaxRound	= 1
x500618_g_ControlScript		= 001066
x500618_g_Custom	= { {id="�� gi�t ch�t T� Ph�m",num=20} }
--MisDescEnd
