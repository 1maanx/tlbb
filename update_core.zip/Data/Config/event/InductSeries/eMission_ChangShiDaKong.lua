--MisDescBegin
x500622_g_ScriptId = 500622
x500622_g_Position_X=177.4994
x500622_g_Position_Z=184.2609
x500622_g_SceneID=0
x500622_g_AccomplishNPC_Name="B�nh Ho�i Ng�c"
x500622_g_MissionId = 1188
x500622_g_MissionIdPre = 1187
x500622_g_Name	="B�nh Ho�i Ng�c"
x500622_g_ItemNeedNum = 1
x500622_g_MissionKind = 11
x500622_g_MissionLevel = 40
x500622_g_IfMissionElite = 0
x500622_g_Custom	= { {id="Ho�n th�nh ��c l�",num=1} }
x500622_g_IsMissionOkFail = 1		--�����ĵ�0λ
x500622_g_MissionName="#{YDXF_XML_2}"
x500622_g_MissionTarget="#{YDXF_091229_8}"
x500622_g_SignPost = {x = 177, z = 184, tip = "B�nh Ho�i Ng�c"}
x500622_g_ItemBonus={id=30900010 ,num=1}
--MisDescEnd
