--MisDescBegin
x500625_g_ScriptId = 500625
x500625_g_Position_X=182.4375
x500625_g_Position_Z=157.3685
x500625_g_SceneID=0
x500625_g_AccomplishNPC_Name="V�n Di�u Di�u"
x500625_g_MissionId = 1191
x500625_g_MissionIdPre = 1190
x500625_g_Name	="V�n Di�u Di�u"
x500625_g_ItemNeedNum = 1
x500625_g_MissionKind = 11
x500625_g_MissionLevel = 45
x500625_g_IfMissionElite = 0
x500625_g_Custom	= { {id="�� � Tr�n Th� h�c k� n�ng",num=2} }
x500625_g_IsMissionOkFail = 1		--�����ĵ�0λ
x500625_g_MissionName="#{YDXF_XML_5}"
x500625_g_MissionTarget="#{YDXF_091229_28}"
x500625_g_SignPost = {x = 177, z = 184, tip = "B�nh Ho�i Ng�c"}
x500625_g_ItemBonus={{id=30402071 ,num=1},{id=30008003,num=1}}
--MisDescEnd
