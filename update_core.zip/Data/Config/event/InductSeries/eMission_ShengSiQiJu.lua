--MisDescBegin
x500601_g_ScriptId	= 500601
x500601_g_Position_X=160.2399
x500601_g_Position_Z=134.1486
x500601_g_SceneID=0
x500601_g_AccomplishNPC_Name="Ch�u Thi�n S�"
x500601_g_PreMissionId	=	407
x500601_g_MissionId			= 408
x500601_g_MissionIdNext	= 409
x500601_g_NextScriptId	= 500602
x500601_g_AcceptNPC_SceneID	=	0
x500601_g_Name 					= "B�c H�i K�"
x500601_g_MissionKind			= 11
x500601_g_MissionLevel		= 28
x500601_g_IfMissionElite	= 0
x500601_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x500601_g_MissionName			= "Sinh T� K� Cu�c"
x500601_g_MissionInfo			= "#{YD_20080421_32}"
x500601_g_MissionTarget		= "#{YD_20080421_31}"
x500601_g_ContinueInfo		= "#{YD_20080421_33}"
x500601_g_MissionComplete	= "#{YD_20080421_34}"
x500601_g_MaxRound	= 1
x500601_g_ControlScript		= 001066
x500601_g_Custom	= { {id="�� gi�t ch�t Vi�n C� K� H�n",num=1} }
--MisDescEnd
