--MisDescBegin
x500614_g_ScriptId	= 500614
x500614_g_Position_X=160.2399
x500614_g_Position_Z=134.1486
x500614_g_SceneID=0
x500614_g_AccomplishNPC_Name="Ch�u Thi�n S�"
x500614_g_PreMissionId	=	436
x500614_g_MissionId			= 437
x500614_g_MissionIdNext	= 438
x500614_g_MissionIndexNext	= 1018718
x500614_g_NextScriptId	= 006668
x500614_g_AcceptNPC_SceneID	=	0
x500614_g_Name 					= "Ch�u Thi�n S�"
x500614_g_MissionKind			= 11
x500614_g_MissionLevel		= 42
x500614_g_IfMissionElite	= 0
x500614_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x500614_g_MissionName			= "Thi�n s� k� ��i (8)"
x500614_g_MissionInfo			= "#{YD_20080421_14}"
x500614_g_MissionTarget		= "#{YD_20080421_105}"
x500614_g_ContinueInfo		= "#{YD_20080421_15}"
x500614_g_MissionComplete	= "#{YD_20080421_16}"
x500614_g_MaxRound	= 1
x500614_g_ControlScript		= 001066
x500614_g_Custom	= { {id="�� th�ng l�n c�p 45",num=1} }
--MisDescEnd
