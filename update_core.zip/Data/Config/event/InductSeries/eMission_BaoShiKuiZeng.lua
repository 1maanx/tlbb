--MisDescBegin
x500621_g_ScriptId = 500621
x500621_g_Position_X=177.4994
x500621_g_Position_Z=184.2609
x500621_g_SceneID=0
x500621_g_AccomplishNPC_Name="B�nh Ho�i Ng�c"
x500621_g_MissionId = 1187
x500621_g_Name	="B�nh Ho�i Ng�c"
x500621_g_MissionKind = 11
x500621_g_MissionLevel = 40
x500621_g_IfMissionElite = 0
x500621_g_MissionName="#{YDXF_XML_1}"
x500621_g_MissionTarget="#{YDXF_091229_2}"
x500621_g_SignPost = {x = 177, z = 184, tip = "B�nh Ho�i Ng�c"}
x500621_g_ItemBonus={{id=50213004 ,num=1},{id=20109004,num=1},{id=10413096,num=1}}
x500621_g_Custom	= { {id="�� t�m ���c B�nh Ho�i Ng�c",num=1} }
x500621_g_IsMissionOkFail = 1		--�����ĵ�0λ
--MisDescEnd
