--MisDescBegin
x500624_g_ScriptId = 500624
x500624_g_Position_X=182.4375
x500624_g_Position_Z=157.3685
x500624_g_SceneID=0
x500624_g_AccomplishNPC_Name="V�n Di�u Di�u"
x500624_g_MissionId = 1190
x500624_g_Name	="V�n Di�u Di�u"
x500624_g_MissionKind = 11
x500624_g_MissionLevel = 45
x500624_g_IfMissionElite = 0
x500624_g_MissionName="#{YDXF_XML_4}"
x500624_g_MissionTarget="#{YDXF_091229_22}"
x500624_g_SignPost = {x = 182, z = 157, tip = "V�n Di�u Di�u"}
x500624_g_ItemBonus={{id=30402010 ,num=1},{id=30402017,num=1}}--,{id=10104000,num=1}
x500624_g_Custom	= { {id="�� t�m ���c V�n Di�u Di�u",num=1} }
x500624_g_IsMissionOkFail = 1		--�����ĵ�0λ
--MisDescEnd
