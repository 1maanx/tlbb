--MisDescBegin
x500602_g_ScriptId	= 500602
x500602_g_Position_X=160.2399
x500602_g_Position_Z=134.1486
x500602_g_SceneID=0
x500602_g_AccomplishNPC_Name="Ch�u Thi�n S�"
x500602_g_PreMissionId	=	408
x500602_g_MissionId			= 409
x500602_g_MissionIdNext	= 410
x500602_g_MissionIndexNext	= 1018706
x500602_g_NextScriptId	= 006668
x500602_g_AcceptNPC_SceneID	=	0
x500602_g_Name 					= "Ch�u Thi�n S�"
x500602_g_MissionKind			= 11
x500602_g_MissionLevel		= 28
x500602_g_IfMissionElite	= 0
x500602_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x500602_g_MissionName			= "Thi�n s� k� ��i (2)"
x500602_g_MissionInfo			= "#{YD_20080421_14}"
x500602_g_MissionTarget		= "#{YD_20080421_35}"
x500602_g_ContinueInfo		= "#{YD_20080421_15}"
x500602_g_MissionComplete	= "#{YD_20080421_16}"
x500602_g_MaxRound	= 1
x500602_g_ControlScript		= 001066
x500602_g_Custom	= { {id="�� th�ng l�n c�p 30",num=1} }
--MisDescEnd
