--MisDescBegin
x500620_g_ScriptId = 500620
x500620_g_Name = "L�p Ph�n"
--MisDescEnd
