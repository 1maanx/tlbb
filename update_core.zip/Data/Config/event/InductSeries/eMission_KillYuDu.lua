--MisDescBegin
x500609_g_ScriptId	= 500609
x500609_g_Position_X=62.6751
x500609_g_Position_Z=162.6368
x500609_g_SceneID=1
x500609_g_AccomplishNPC_Name="Ti�n Ho�nh V�"
x500609_g_PreMissionId	=	419
x500609_g_MissionId			= 422
x500609_g_MissionIdNext	= 423
x500609_g_MissionIndexNext	= 1018710
x500609_g_NextScriptId	= 006668
x500609_g_AcceptNPC_SceneID	=	1
x500609_g_Name 					= "Ti�n Ho�nh V�"
x500609_g_MissionKind			= 12
x500609_g_MissionLevel		= 38
x500609_g_IfMissionElite	= 0
x500609_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x500609_g_MissionName			= "Ti�u di�t D� еc"
x500609_g_MissionInfo			= "#{YD_20080421_64}"
x500609_g_MissionTarget		= "#{YD_20080421_63}"
x500609_g_ContinueInfo		= "#{YD_20080421_193}"
x500609_g_MissionComplete	= "#{YD_20080421_65}"
x500609_g_MaxRound	= 1
x500609_g_ControlScript		= 001066
x500609_g_Custom	= { {id="�� gi�t ch�t D� еc",num=1} }
--MisDescEnd
