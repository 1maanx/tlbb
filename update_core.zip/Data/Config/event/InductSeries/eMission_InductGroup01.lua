--MisDescBegin
x500600_g_ScriptId	= 500600
x500600_g_Position_X=160.2399
x500600_g_Position_Z=134.1486
x500600_g_SceneID=0
x500600_g_AccomplishNPC_Name="Ch�u Thi�n S�"
x500600_g_PreMissionId	=	401
x500600_g_MissionId			= 402
x500600_g_MissionIdNext	= 403
x500600_g_NextScriptId	= 500606
x500600_g_AcceptNPC_SceneID	=	0
x500600_g_Name 					= "Ng� Th� Nh�n"
x500600_g_MissionKind			= 11
x500600_g_MissionLevel		= 26
x500600_g_IfMissionElite	= 0
x500600_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x500600_g_MissionName			= "T� �i luy�n c�p"
x500600_g_MissionInfo			= "#{YD_20080421_10}"
x500600_g_MissionTarget		= "#{YD_20080421_09}"
x500600_g_ContinueInfo		= "#{YD_20080421_11}"
x500600_g_MissionComplete	= "#{YD_20080421_12}"
x500600_g_MaxRound	= 1
x500600_g_ControlScript		= 001066
x500600_g_Custom	= { {id="T� �i ph�i l� 1 �i 2 ng߶i tr� l�n",num=1} }
--MisDescEnd
