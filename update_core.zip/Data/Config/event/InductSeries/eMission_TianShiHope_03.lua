--MisDescBegin
x500603_g_ScriptId	= 500603
x500603_g_Position_X=160.2399
x500603_g_Position_Z=134.1486
x500603_g_SceneID=0
x500603_g_AccomplishNPC_Name="Ch�u Thi�n S�"
x500603_g_PreMissionId	=	411
x500603_g_MissionId			= 412
x500603_g_MissionIdNext	= 413
x500603_g_MissionIndexNext	= 1018707
x500603_g_NextScriptId	= 006668
x500603_g_AcceptNPC_SceneID	=	0
x500603_g_Name 					= "Ch�u Thi�n S�"
x500603_g_MissionKind			= 11
x500603_g_MissionLevel		= 30
x500603_g_IfMissionElite	= 0
x500603_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x500603_g_MissionName			= "Thi�n s� k� ��i (3)"
x500603_g_MissionInfo			= "#{YD_20080421_14}"
x500603_g_MissionTarget		= "#{YD_20080421_43}"
x500603_g_ContinueInfo		= "#{YD_20080421_15}"
x500603_g_MissionComplete	= "#{YD_20080421_16}"
x500603_g_MaxRound	= 1
x500603_g_ControlScript		= 001066
x500603_g_Custom	= { {id="�� th�ng l�n c�p 32",num=1} }
--MisDescEnd
