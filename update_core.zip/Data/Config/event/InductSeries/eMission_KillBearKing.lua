--MisDescBegin
x500610_g_ScriptId	= 500610
x500610_g_Position_X=251.1648
x500610_g_Position_Z=108.9732
x500610_g_SceneID=1
x500610_g_AccomplishNPC_Name="Hoa Ki�m V�"
x500610_g_PreMissionId	=	423
x500610_g_MissionId			= 424
x500610_g_MissionIdNext	= 425
x500610_g_MissionIndexNext	= 1018711
x500610_g_NextScriptId	= 006668
x500610_g_AcceptNPC_SceneID	=	1
x500610_g_Name 					= "Hoa Ki�m V�"
x500610_g_MissionKind			= 12
x500610_g_MissionLevel		= 38
x500610_g_IfMissionElite	= 0
x500610_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x500610_g_MissionName			= "Ti�u di�t H�ng H�ng V߽ng"
x500610_g_MissionInfo			= "#{YD_20080421_70}"
x500610_g_MissionTarget		= "#{YD_20080421_69}"
x500610_g_ContinueInfo		= "#{YD_20080421_194}"
x500610_g_MissionComplete	= "#{YD_20080421_71}"
x500610_g_MaxRound	= 1
x500610_g_ControlScript		= 001066
x500610_g_Custom	= { {id="�� gi�t ch�t H�ng H�ng V߽ng",num=1} }
--MisDescEnd
