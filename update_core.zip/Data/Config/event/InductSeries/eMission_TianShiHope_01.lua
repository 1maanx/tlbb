--MisDescBegin
x500606_g_ScriptId	= 500606
x500606_g_Position_X=160.2399
x500606_g_Position_Z=134.1486
x500606_g_SceneID=0
x500606_g_AccomplishNPC_Name="Ch�u Thi�n S�"
x500606_g_PreMissionId	=	402
x500606_g_MissionId			= 403
x500606_g_MissionIdNext	= 404
x500606_g_MissionIndexNext	= 1018702
x500606_g_NextScriptId	= 006668
x500606_g_AcceptNPC_SceneID	=	0
x500606_g_Name 					= "Ch�u Thi�n S�"
x500606_g_MissionKind			= 11
x500606_g_MissionLevel		= 26
x500606_g_IfMissionElite	= 0
x500606_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x500606_g_MissionName			= "Thi�n s� k� ��i (1)"
x500606_g_MissionInfo			= "#{YD_20080421_14}"
x500606_g_MissionTarget		= "#{YD_20080421_13}"
x500606_g_ContinueInfo		= "#{YD_20080421_15}"
x500606_g_MissionComplete	= "#{YD_20080421_16}"
x500606_g_MaxRound	= 1
x500606_g_ControlScript		= 001066
x500606_g_Custom	= { {id="�� th�ng l�n c�p 28",num=1} }
--MisDescEnd
