--MisDescBegin
x500607_g_ScriptId	= 500607
x500607_g_Position_X=160.2399
x500607_g_Position_Z=134.1486
x500607_g_SceneID=0
x500607_g_AccomplishNPC_Name="Ch�u Thi�n S�"
x500607_g_PreMissionId	=	416
x500607_g_MissionId			= 417
x500607_g_MissionIdNext	= 418
x500607_g_NextScriptId	= 500608
x500607_g_AcceptNPC_SceneID	=	0
x500607_g_Name 					= "L�p Ph�n"
x500607_g_MissionKind			= 11
x500607_g_MissionLevel		= 35
x500607_g_IfMissionElite	= 0
x500607_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x500607_g_MissionName			= "Giang h� ti�u ti�u"
x500607_g_MissionInfo			= "#{YD_20080421_57}"
x500607_g_MissionTarget		= "#{YD_20080421_56}"
x500607_g_ContinueInfo		= "#{YD_20080421_190}"
x500607_g_MissionComplete	= "#{YD_20080421_58}"
x500607_g_MaxRound	= 1
x500607_g_ControlScript		= 001066
x500607_g_Custom	= { {id="�� gi�t ch�t �c B�",num=1} }
--MisDescEnd
