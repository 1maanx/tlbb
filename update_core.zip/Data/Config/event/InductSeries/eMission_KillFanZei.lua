--MisDescBegin
x500604_g_ScriptId	= 500604
x500604_g_Position_X=160.2399
x500604_g_Position_Z=134.1486
x500604_g_SceneID=0
x500604_g_AccomplishNPC_Name="Ch�u Thi�n S�"
x500604_g_PreMissionId	=	413
x500604_g_MissionId			= 414
x500604_g_MissionIdNext	= 415
x500604_g_NextScriptId	= 500605
x500604_g_AcceptNPC_SceneID	=	0
x500604_g_Name 					= "L�p Ph�n"
x500604_g_MissionKind			= 11
x500604_g_MissionLevel		= 32
x500604_g_IfMissionElite	= 0
x500604_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x500604_g_MissionName			= "�c T�c T�o Ph�n"
x500604_g_MissionInfo			= "#{YD_20080421_49}"
x500604_g_MissionTarget		= "#{YD_20080421_48}"
x500604_g_ContinueInfo		= "#{YD_20080421_185}"
x500604_g_MissionComplete	= "#{YD_20080421_50}"
x500604_g_MaxRound	= 1
x500604_g_ControlScript		= 001066
x500604_g_Custom	= { {id="�� gi�t ch�t T�c Binh Хu M�c",num=1} }
--MisDescEnd
