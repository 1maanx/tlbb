--MisDescBegin
x500611_g_ScriptId	= 500611
x500611_g_Position_X=62.6751
x500611_g_Position_Z=162.6368
x500611_g_SceneID=1
x500611_g_AccomplishNPC_Name="Ti�n Ho�nh V�"
x500611_g_PreMissionId	=	425
x500611_g_MissionId			= 426
x500611_g_MissionIdNext	= 427
x500611_g_AcceptNPC_SceneID	=	1
x500611_g_Name 					= "Ti�n Ho�nh V�"
x500611_g_MissionKind			= 12
x500611_g_MissionLevel		= 38
x500611_g_IfMissionElite	= 0
x500611_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x500611_g_MissionName			= "Ti�u di�t S�n Tr�i ��i V߽ng"
x500611_g_MissionInfo			= "#{YD_20080421_75}"
x500611_g_MissionTarget		= "#{YD_20080421_74}"
x500611_g_ContinueInfo		= "#{YD_20080421_195}"
x500611_g_MissionComplete	= "#{YD_20080421_76}"
x500611_g_MaxRound	= 1
x500611_g_ControlScript		= 001066
x500611_g_Custom	= { {id="�� gi�t ch�t S�n Tr�i ��i V߽ng",num=1} }
--MisDescEnd
