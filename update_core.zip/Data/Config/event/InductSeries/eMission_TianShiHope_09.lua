--MisDescBegin
x500615_g_ScriptId	= 500615
x500615_g_Position_X=160.2399
x500615_g_Position_Z=134.1486
x500615_g_SceneID=0
x500615_g_AccomplishNPC_Name="Ch�u Thi�n S�"
x500615_g_PreMissionId	=	475
x500615_g_MissionId			= 476
x500615_g_MissionIdNext	= 477
x500615_g_MissionIndexNext	= 1018724
x500615_g_NextScriptId	= 006668
x500615_g_AcceptNPC_SceneID	=	0
x500615_g_Name 					= "Ch�u Thi�n S�"
x500615_g_MissionKind			= 11
x500615_g_MissionLevel		= 45
x500615_g_IfMissionElite	= 0
x500615_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x500615_g_MissionName			= "Thi�n s� k� ��i (9)"
x500615_g_MissionInfo			= "#{YD_20080421_14}"
x500615_g_MissionTarget		= "#{YD_20080421_132}"
x500615_g_ContinueInfo		= "#{YD_20080421_15}"
x500615_g_MissionComplete	= "#{YD_20080421_16}"
x500615_g_MaxRound	= 1
x500615_g_ControlScript		= 001066
x500615_g_Custom	= { {id="�� th�ng l�n c�p 48",num=1} }
--MisDescEnd
