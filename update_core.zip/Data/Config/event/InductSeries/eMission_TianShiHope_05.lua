--MisDescBegin
x500608_g_ScriptId	= 500608
x500608_g_Position_X=160.2399
x500608_g_Position_Z=134.1486
x500608_g_SceneID=0
x500608_g_AccomplishNPC_Name="Ch�u Thi�n S�"
x500608_g_PreMissionId	=	417
x500608_g_MissionId			= 418
x500608_g_MissionIdNext	= 419
x500608_g_MissionIndexNext	= 1018709
x500608_g_NextScriptId	= 006668
x500608_g_AcceptNPC_SceneID	=	0
x500608_g_Name 					= "Ch�u Thi�n S�"
x500608_g_MissionKind			= 11
x500608_g_MissionLevel		= 35
x500608_g_IfMissionElite	= 0
x500608_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x500608_g_MissionName			= "Thi�n s� k� ��i (5)"
x500608_g_MissionInfo			= "#{YD_20080421_14}"
x500608_g_MissionTarget		= "#{YD_20080421_59}"
x500608_g_ContinueInfo		= "#{YD_20080421_15}"
x500608_g_MissionComplete	= "#{YD_20080421_16}"
x500608_g_MaxRound	= 1
x500608_g_ControlScript		= 001066
x500608_g_Custom	= { {id="�� th�ng l�n c�p 38",num=1} }
--MisDescEnd
