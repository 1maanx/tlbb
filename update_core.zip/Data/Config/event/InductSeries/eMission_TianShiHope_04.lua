--MisDescBegin
x500605_g_ScriptId	= 500605
x500605_g_Position_X=160.2399
x500605_g_Position_Z=134.1486
x500605_g_SceneID=0
x500605_g_AccomplishNPC_Name="Ch�u Thi�n S�"
x500605_g_PreMissionId	=	414
x500605_g_MissionId			= 415
x500605_g_MissionIdNext	= 416
x500605_g_MissionIndexNext	= 1018708
x500605_g_NextScriptId	= 006668
x500605_g_AcceptNPC_SceneID	=	0
x500605_g_Name 					= "Ch�u Thi�n S�"
x500605_g_MissionKind			= 11
x500605_g_MissionLevel		= 32
x500605_g_IfMissionElite	= 0
x500605_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x500605_g_MissionName			= "Thi�n s� k� ��i (4)"
x500605_g_MissionInfo			= "#{YD_20080421_14}"
x500605_g_MissionTarget		= "#{YD_20080421_51}"
x500605_g_ContinueInfo		= "#{YD_20080421_15}"
x500605_g_MissionComplete	= "#{YD_20080421_16}"
x500605_g_MaxRound	= 1
x500605_g_ControlScript		= 001066
x500605_g_Custom	= { {id="�� th�ng l�n c�p 35",num=1} }
--MisDescEnd
