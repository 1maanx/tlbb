--MisDescBegin
x500612_g_ScriptId	= 500612
x500612_g_Position_X=160.2399
x500612_g_Position_Z=134.1486
x500612_g_SceneID=0
x500612_g_AccomplishNPC_Name="Ch�u Thi�n S�"
x500612_g_PreMissionId	=	427
x500612_g_MissionId			= 428
x500612_g_MissionIdNext	= 429
x500612_g_MissionIndexNext	= 1018713
x500612_g_NextScriptId	= 006668
x500612_g_AcceptNPC_SceneID	=	0
x500612_g_Name 					= "Ch�u Thi�n S�"
x500612_g_MissionKind			= 11
x500612_g_MissionLevel		= 38
x500612_g_IfMissionElite	= 0
x500612_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x500612_g_MissionName			= "Thi�n s� k� ��i (6)"
x500612_g_MissionInfo			= "#{YD_20080421_14}"
x500612_g_MissionTarget		= "#{YD_20080421_80}"
x500612_g_ContinueInfo		= "#{YD_20080421_15}"
x500612_g_MissionComplete	= "#{YD_20080421_16}"
x500612_g_MaxRound	= 1
x500612_g_ControlScript		= 001066
x500612_g_Custom	= { {id="�� th�ng l�n c�p 40",num=1} }
--MisDescEnd
