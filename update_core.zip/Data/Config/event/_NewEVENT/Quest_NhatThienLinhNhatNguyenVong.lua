--MisDescBegin
x960010_g_ScriptId = 960010
x960010_g_Position_X = 188
x960010_g_Position_Z = 185
x960010_g_SceneID = 1
x960010_g_AccomplishNPC_Name = "L߽ng ��o S�"
x960010_g_MissionId = 623
x960010_g_Name	= "L߽ng ��o S�"
x960010_g_ItemNeedNum = 5
x960010_g_MissionKind = 12
x960010_g_MissionLevel = 30
x960010_g_IfMissionElite = 0
x960010_g_Custom = { {id="H�a h�n v�i H�a Nguy�n Th�",num=5} }
x960010_g_IsMissionOkFail = 1
x960010_g_MissionName="#{SQXY_09061_4}"
x960010_g_MissionTarget = "#{SQXY_09061_11}"
x960010_g_SignPost = {x = 188, z = 185, tip = "L߽ng ��o S�"}
x960010_g_ItemBonus={{id=20502010 ,num=1}}
x960010_g_MoneyBonus=20000
--MisDescEnd

