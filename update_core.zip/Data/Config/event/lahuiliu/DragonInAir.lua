--MisDescBegin
x809326_g_ScriptId = 809326
x809326_g_CopySceneName	= ""
x809326_g_MissionId			= 1151
x809326_g_MissionIdPre	= 0
x809326_g_Name					= "T�n B�t Gia"
x809326_g_IfMissionElite= 0
x809326_g_IsMissionOkFail = 0		--�����ĵ�0λ
x809326_g_MissionLevel	= 10000
x809326_g_MissionKind		= 1
x809326_g_MissionName			= "#{FLZT_100804_46}"
x809326_g_MissionInfo			= ""
x809326_g_MissionTarget		= "#{FLZT_100804_15}"
x809326_g_Custom				= { {id="�� m� Thi�n Long tr�n b�o nang",num=1}}
--MisDescEnd
