--MisDescBegin
x809327_g_ScriptId = 809327
x809327_g_MissionId = 1143
x809327_g_MissionName= "#{SLHL_20100913_01}"
x809327_g_AccomplishNPC_Name="T�n B�t Gia" 
x809327_g_Position_X=172.7304
x809327_g_Position_Z=146.4640
x809327_g_AccomplishNPC_SceneID = 2
x809327_g_MissionKind = 1
x809327_g_MissionLevel = 10000
x809327_g_MissionTarget="#{SLHL_20100913_19}"
x809327_g_Custom	= { {id="�� m� S� S�c u�n linh kh� ",num=99} }
--MisDescEnd
