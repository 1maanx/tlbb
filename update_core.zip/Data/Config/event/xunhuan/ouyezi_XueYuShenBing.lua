--MisDescBegin
x500503_g_ScriptId	= 500503
x500503_g_Position_X=266.2833
x500503_g_Position_Z=140.0340
x500503_g_SceneID=1
x500503_g_AccomplishNPC_Name="�u D� T�"
x500503_g_MissionId			= 420
x500503_g_MissionIdNext	= 420
x500503_g_Name			= "�u D� T�"
x500503_g_MissionKind			= 55
x500503_g_MissionLevel		= 10000
x500503_g_IfMissionElite	= 0
x500503_g_IsMissionOkFail	= 0		--�����ĵ�0λ
x500503_g_RandomCustom = {{ id = "�� gi�t ch�t qu�i v�t", numNeeded = 3, numComplete = 1 }}
x500503_g_MissionName			= "Huy�t D�c Th�n Binh"
x500503_g_MissionInfo			= "��c th�n kh�"
x500503_g_MissionTarget		= "#{XYSB_20070928_010}"
x500503_g_ContinueInfo		= "#{XYSB_20070928_009}"
x500503_g_MissionComplete	= "Vi�c ta giao �� ho�n th�nh ch�a?"
x500503_g_MaxRound	= 0
x500503_g_ControlScript		= 001066
--MisDescEnd
