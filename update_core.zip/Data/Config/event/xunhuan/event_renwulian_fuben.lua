--MisDescBegin
x229023_g_scriptId = 229023
x229023_g_MissionId = 1202
--MisDescEnd
