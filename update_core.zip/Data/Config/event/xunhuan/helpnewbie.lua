--MisDescBegin
x210254_g_ScriptId = 210254
x210254_g_MsgBallIdx = 38
x210254_g_Position_X=145.4745
x210254_g_Position_Z=138.5048
x210254_g_SceneID=2
x210254_g_AccomplishNPC_Name="Ti�n Long"
x210254_g_MissionId = 1192
x210254_g_ItemId = 40004512
x210254_g_RewardItemId = 30503153
x210254_g_Name	="Ti�n Long"
x210254_g_MissionKind = 1
x210254_g_MissionLevel = 10000
x210254_g_IfMissionElite = 0
x210254_g_MissionName="#{LDX_100112_01}"
x210254_g_MissionInfo="Th�ng tin nhi�m v�"
x210254_g_MissionTarget="#{LDX_100112_09}"
x210254_g_MissionComplete="Nhi�m v� ho�n th�nh"
x210254_g_MoneyBonus=0
x210254_g_SignPost = {x = 145, z = 138, tip = "Ti�n Long"}
x210254_g_ItemBonus={{id=30503153,num=5}}
x210254_g_Custom	= { {id="�� �y long hi�p ngh�a",num=1} }
x210254_g_IsMissionOkFail = 1 --�����ĵ�0λ
--MisDescEnd
