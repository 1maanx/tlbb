--MisDescBegin
x228904_g_ScriptId = 228904
x228904_g_Position_X = 217
x228904_g_Position_Z = 255
x228904_g_SceneID = 2
x228904_g_AccomplishNPC_Name = "V߽ng Thi�u"
x228904_g_MissionId = 949
x228904_g_PreMissionId = 948
x228904_g_Name = "V߽ng Thi�u"
x228904_g_MissionKind = 28
x228904_g_MissionLevel = 30
x228904_g_IfMissionElite = 0
x228904_g_MissionName = "Du s�n ngo�n th�y"
x228904_g_MissionInfo = "#{TIANSHAN_SKILL_06}"
x228904_g_MissionTarget = "    Mang 5 v�ng �n Tu V�n ��i � th�nh ��i L�#W giao cho #RV߽ng Thi�u #W#{_INFOAIM217,255,2,V߽ng Thi�u}. "
x228904_g_MissionContinue = "#{TIANSHAN_SKILL_07}"
x228904_g_MissionComplete = "#{TIANSHAN_SKILL_08}"
x228904_g_MoneyCost = 50000
x228904_g_MoneyBonus = 1000
x228904_g_exp = 2000
x228904_g_IsMissionOkFail = 0					-- �Ƿ��������ı��λ
x228904_g_IsFindTarget = 1						-- �Ƿ��ҵ����ر��λ
--MisDescEnd
