--MisDescBegin
x889819_g_ScriptId			= 889819
x889819_g_AcceptNPC_Name = "��i S� Chinh Chi�n"
x889819_g_AccomplishNPC_Name = "T�n B�t Gia" 
x889819_g_SceneID						= 2
x889819_g_Position_X					= 173
x889819_g_Position_Z					= 146
x889819_g_CopySceneName		= ""
x889819_g_MissionId			= 1247
x889819_g_MissionIdPre		= 0
x889819_g_Name				= ""
x889819_g_IfMissionElite	= 1
x889819_g_MissionLevel		= 10000
x889819_g_MissionKind		= 1
x889819_g_MissionName		= "#{ZZLY_100910_10}"
x889819_g_MissionInfo		= "#{ZZLY_100910_12}"
x889819_g_MissionTarget		= "#{ZZLY_100910_21}"
x889819_g_NPC_Boss 			= "L� Thu Thu�"
x889819_g_Param_IsMissionOkFail	= 0						--0�ţ���ǰ�����Ƿ����(0δ��ɣ�1���)
x889819_g_Custom			= { {id="�� Ho�n Th�nh Ti�u Phi�u Mi�u Phong", num=1}}
--MisDescEnd
