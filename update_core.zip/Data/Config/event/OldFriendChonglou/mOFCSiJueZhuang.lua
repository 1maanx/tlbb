--MisDescBegin
x889817_g_ScriptId			= 889817
x889817_g_AcceptNPC_Name = "��i S� Chinh Chi�n"
x889817_g_AccomplishNPC_Name = "T�n B�t Gia" 
x889817_g_SceneID						= 2
x889817_g_Position_X					= 173
x889817_g_Position_Z					= 146
x889817_g_CopySceneName		= ""
x889817_g_MissionId			= 1245
x889817_g_MissionIdPre		= 0
x889817_g_Name				= ""
x889817_g_IfMissionElite	= 1
x889817_g_MissionLevel		= 10000
x889817_g_MissionKind		= 1
x889817_g_MissionName		= "#{ZZLY_100910_08}"
x889817_g_MissionInfo		= "#{ZZLY_100910_12}"
x889817_g_MissionTarget		= "#{ZZLY_100910_19}"
x889817_g_NPC_Boss 			= "B�ng X�"
x889817_g_Param_IsMissionOkFail	= 0						--0�ţ���ǰ�����Ƿ����(0δ��ɣ�1���)
x889817_g_Custom			= { {id="�� Ho�n Th�nh �n O�n T� Tuy�t Trang",num=1}}
--MisDescEnd
