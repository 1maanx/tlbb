--MisDescBegin
x889814_g_ScriptId			= 889814
x889814_g_AcceptNPC_Name = "��i S� Chinh Chi�n"
x889814_g_AccomplishNPC_Name = "T�n B�t Gia" 
x889814_g_SceneID						= 2
x889814_g_Position_X					= 173
x889814_g_Position_Z					= 146
x889814_g_CopySceneName		= ""
x889814_g_MissionId			= 1242
x889814_g_MissionIdPre		= 0
x889814_g_Name				= ""
x889814_g_IfMissionElite	= 1
x889814_g_MissionLevel		= 10000
x889814_g_MissionKind		= 1
x889814_g_MissionName		= "#{ZZLY_100910_05}"
x889814_g_MissionInfo		= "#{ZZLY_100910_12}"
x889814_g_MissionTarget		= "#{ZZLY_100910_16}"
x889814_g_NPC_Boss 			= "Tr�n B�o Long V߽ng"
x889814_g_Param_IsMissionOkFail	= 0						--0�ţ���ǰ�����Ƿ����(0δ��ɣ�1���)
x889814_g_Custom			= { {id="�� Ho�n Th�nh L�u Lan T�m B�o",num=1}}
--MisDescEnd
