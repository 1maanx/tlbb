--MisDescBegin
x889815_g_ScriptId			= 889815
x889815_g_AcceptNPC_Name = "��i S� Chinh Chi�n"
x889815_g_AccomplishNPC_Name = "T�n B�t Gia" 
x889815_g_SceneID						= 2
x889815_g_Position_X					= 173
x889815_g_Position_Z					= 146
x889815_g_CopySceneName		= ""
x889815_g_MissionId			= 1243
x889815_g_MissionIdPre		= 0
x889815_g_Name				= ""
x889815_g_IfMissionElite	= 1
x889815_g_MissionLevel		= 10000
x889815_g_MissionKind		= 1
x889815_g_MissionName		= "#{ZZLY_100910_06}"
x889815_g_MissionInfo		= "#{ZZLY_100910_12}"
x889815_g_MissionTarget		= "#{ZZLY_100910_17}"
x889815_g_NPC_Boss 			= {"S�n Tr�i ��i V߽ng", "C�t Vinh Ph�n N�"}
x889815_g_Param_IsMissionOkFail	= 0						--0�ţ���ǰ�����Ƿ����(0δ��ɣ�1���)
x889815_g_Custom			= { {id="�� Ho�n Th�nh L�o Tam Ho�n",num=1}}
--MisDescEnd
