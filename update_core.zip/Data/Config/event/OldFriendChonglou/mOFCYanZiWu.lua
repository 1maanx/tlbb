--MisDescBegin
x889820_g_ScriptId			= 889820
x889820_g_AcceptNPC_Name = "��i S� Chinh Chi�n"
x889820_g_AccomplishNPC_Name = "T�n B�t Gia" 
x889820_g_SceneID						= 2
x889820_g_Position_X					= 173
x889820_g_Position_Z					= 146
x889820_g_CopySceneName		= ""
x889820_g_MissionId			= 1248
x889820_g_MissionIdPre		= 0
x889820_g_Name				= ""
x889820_g_IfMissionElite	= 1
x889820_g_MissionLevel		= 10000
x889820_g_MissionKind		= 1
x889820_g_MissionName		= "#{ZZLY_100910_11}"
x889820_g_MissionInfo		= "#{ZZLY_100910_12}"
x889820_g_MissionTarget		= "#{ZZLY_100910_22}"
x889820_g_NPC_Boss 			= "M� Dung Ph�c"
x889820_g_Param_IsMissionOkFail	= 0						--0�ţ���ǰ�����Ƿ����(0δ��ɣ�1���)
x889820_g_Custom			= { {id="�� Ho�n Th�nh � y�n T�",num=1}}
--MisDescEnd
