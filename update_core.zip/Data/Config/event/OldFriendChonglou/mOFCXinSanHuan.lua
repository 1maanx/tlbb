--MisDescBegin
x889816_g_ScriptId			= 889816
x889816_g_AcceptNPC_Name = "��i S� Chinh Chi�n"
x889816_g_AccomplishNPC_Name = "T�n B�t Gia" 
x889816_g_SceneID						= 2
x889816_g_Position_X					= 173
x889816_g_Position_Z					= 146
x889816_g_CopySceneName		= ""
x889816_g_MissionId			= 1244
x889816_g_MissionIdPre		= 0
x889816_g_Name				= ""
x889816_g_IfMissionElite	= 1
x889816_g_MissionLevel		= 10000
x889816_g_MissionKind		= 1
x889816_g_MissionName		= "#{ZZLY_100910_07}"
x889816_g_MissionInfo		= "#{ZZLY_100910_12}"
x889816_g_MissionTarget		= "#{ZZLY_100910_18}" 
x889816_g_NPC_Boss 			= "H�a Di�m Y�u Ma"
x889816_g_Param_IsMissionOkFail	= 0						--0�ţ���ǰ�����Ƿ����(0δ��ɣ�1���)
x889816_g_Custom			= { {id="�� Ho�n Th�nh T�n Tam Ho�n",num=1}}
--MisDescEnd
