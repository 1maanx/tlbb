--MisDescBegin
x050059_g_ScriptId = 050059
x050059_g_MissionName = "Mua nhi�u qu� T�t m�n ph�i"
--MisDescEnd
