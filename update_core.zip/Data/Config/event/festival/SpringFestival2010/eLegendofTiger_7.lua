--MisDescBegin
x050078_g_ScriptId = 050078
x050078_g_MissionId = 1185
x050078_g_MissionKind = 13
x050078_g_MissionLevel = 10000
x050078_g_IfMissionElite = 0
x050078_g_MissionName="#{SXGS_091105_43}"
x050078_g_MissionTarget="#{SXGS_091105_45}"
x050078_g_IsMissionOkFail = 0
x050078_g_Custom1 = {{id = "�� t�m th�y Ng� C�t Хu",num = 1}}
x050078_g_Custom2 = {{id = "�� ho�n th�nh cu�c truy t�m cu�i c�ng",num = 1}}
x050078_g_MissionRound = 387
--MisDescEnd
