--MisDescBegin
x050072_g_ScriptId = 050072
x050072_g_MissionId = 1179
x050072_g_MissionKind = 13
x050072_g_MissionLevel = 10000
x050072_g_IfMissionElite = 0
x050072_g_MissionName="#{SXGS_091105_02}"
x050072_g_MissionTarget="#{SXGS_091105_09}"
x050072_g_IsMissionOkFail = 0
x050072_g_Custom = {{id = "�� t�m th�y Tri�u Thi�n S�",num = 1}}
x050072_g_MissionRound = 387
x050072_g_Position_X=160
x050072_g_Position_Z=157
x050072_g_SceneID=2
x050072_g_AccomplishNPC_Name="Tri�u Thi�n S�"
--MisDescEnd
