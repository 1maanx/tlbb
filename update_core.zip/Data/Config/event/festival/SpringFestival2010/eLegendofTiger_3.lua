--MisDescBegin
x050074_g_ScriptId = 050074
x050074_g_MissionId = 1181
x050074_g_MissionKind = 11
x050074_g_MissionLevel = 10000
x050074_g_IfMissionElite = 0
x050074_g_MissionName="#{SXGS_091105_17}"
x050074_g_MissionTarget="#{SXGS_091105_19}"
x050074_g_IsMissionOkFail = 0		
x050074_g_Custom = {{id = "�� t�m th�y Ng�i H�",num = 1}}
x050074_g_MissionRound = 387
x050074_g_Position_X=87
x050074_g_Position_Z=140
x050074_g_SceneID=1
x050074_g_AccomplishNPC_Name="Ng�i H�"
--MisDescEnd
