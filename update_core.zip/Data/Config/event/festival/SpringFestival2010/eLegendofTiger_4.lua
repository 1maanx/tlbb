--MisDescBegin
x050075_g_ScriptId = 050075
x050075_g_MissionId = 1182
x050075_g_MissionKind = 12
x050075_g_MissionLevel = 10000
x050075_g_IfMissionElite = 0
x050075_g_MissionName="#{SXGS_091105_22}"
x050075_g_MissionTarget="%f"
x050075_g_StrForePart = 4
x050075_g_FormatList = {"%s%s%s",}
x050075_g_StrList = {
"#{SXGS_091105_24}",
"H�u T� Tr߷ng Th�nh#{_INFOAIM203,69,112,}",	--3050
"C�u T� Tr߷ng Th�nh#{_INFOAIM234,57,112,}",	--3030
"Nh�m Tr߷ng Th�nh#{_INFOAIM139,111,112,}",	--3040
"Ho�n H�ng Tr߷ng Th�nh#{_INFOAIM115,122,112,}",--3070
"T�ng Th� Tr߷ng Th�nh#{_INFOAIM175,128,112,}",	--3060
"Anh V� Tr߷ng Th�nh#{_INFOAIM153,157,112,}",	--3080
"Bi�n B�c Tr߷ng Th�nh#{_INFOAIM228,166,112,}",	--3100
"�߶ng Lang Tr߷ng Th�nh#{_INFOAIM59,151,112,}",	--3110
"T�ch D�ch Tr߷ng Th�nh#{_INFOAIM101,155,112,}",	--3090
"Hoan Tr߷ng Th�nh#{_INFOAIM62,256,112,}",--3140
"H� Tr߷ng Th�nh#{_INFOAIM96,254,112,}",	--3150
"Mi�u Хu �ng Tr߷ng Th�nh#{_INFOAIM61,218,112,}",	--3130
"D� Tr� Tr߷ng Th�nh#{_INFOAIM127,254,112,}",	--3160
"B�o Tr߷ng Th�nh#{_INFOAIM250,236,112,}",	--3200
"B�ng T�m Tr߷ng Th�nh#{_INFOAIM192,232,112,}",	--3170
"�� �i�u Tr߷ng Th�nh#{_INFOAIM181,268,112,}",	--3190
"�ng Tr߷ng Th�nh#{_INFOAIM216,270,112,}",	--3180
"B�c C�c H�ng Tr߷ng Th�nh#{_INFOAIM216,223,112,}",	--3210
"Tinh Tinh Tr߷ng Th�nh#{_INFOAIM276,121,112,}",	--3240
"Ki�m X� H� Tr߷ng Th�nh#{_INFOAIM285,149,112,}",	--3230
"Kh�ng T߾c Tr߷ng Th�nh#{_INFOAIM263,166,112,}",	--3220
"B�c M� Tr߷ng Th�nh#{_INFOAIM247,98,112,}",	--3280
"Ki�m Long Tr߷ng Th�nh#{_INFOAIM275,85,112,}",	--3270
"T� Ng�u Tr߷ng Th�nh#{_INFOAIM227,92,112,}",	--3250
"B�o Tr߷ng Th�nh#{_INFOAIM250,236,112,}",	--3200
"B�ng T�m Tr߷ng Th�nh#{_INFOAIM192,232,112,}",	--3170
"�� �i�u Tr߷ng Th�nh#{_INFOAIM181,268,112,}",	--3190
"�ng Tr߷ng Th�nh#{_INFOAIM216,270,112,}",	--3180
"B�c C�c H�ng Tr߷ng Th�nh#{_INFOAIM216,223,112,}",	--3210
"Tinh Tinh Tr߷ng Th�nh#{_INFOAIM276,121,112,}",	--3240
"Ki�m X� H� Tr߷ng Th�nh#{_INFOAIM285,149,112,}",	--3230
"Kh�ng T߾c Tr߷ng Th�nh#{_INFOAIM263,166,112,}",	--3220
"Hoan Tr߷ng Th�nh#{_INFOAIM62,256,112,}",	--3140
"H� Tr߷ng Th�nh#{_INFOAIM96,254,112,}",	--3150
"Mi�u Хu �ng Tr߷ng Th�nh#{_INFOAIM61,218,112,}",	--3130
"D� Tr� Tr߷ng Th�nh#{_INFOAIM127,254,112,}",	--3160
"T�ch D�ch Tr߷ng Th�nh#{_INFOAIM101,155,112,}",	--3090
"Bi�n B�c Tr߷ng Th�nh#{_INFOAIM228,166,112,}",	--3100
"�߶ng Lang Tr߷ng Th�nh#{_INFOAIM59,151,112,}",	--3110
"Ng�c Ng� Tr߷ng Th�nh#{_INFOAIM68,121,112,}",	--3120
"#{SXGS_091105_25}",   
}
x050075_g_IsMissionOkFail = 0		
x050075_g_Custom = {{id = "�� b�t ���c tr�n th�",num = 1}}
x050075_g_MissionRound = 387
x050075_g_Position_X=87
x050075_g_Position_Z=140
x050075_g_SceneID=1
x050075_g_AccomplishNPC_Name="Ng�i H�"
--MisDescEnd
