--MisDescBegin
x050076_g_ScriptId = 050076
x050076_g_MissionId = 1183
x050076_g_MissionKind = 12
x050076_g_MissionLevel = 10000
x050076_g_IfMissionElite = 0
x050076_g_MissionName="#{SXGS_091105_27}"
x050076_g_MissionTarget="#{SXGS_091105_29}"
x050076_g_IsMissionOkFail = 0
x050076_g_Custom = {{id = "�� t�m ���c A Nguy�t",num = 1}}
x050076_g_MissionRound = 387
x050076_g_Position_X=159
x050076_g_Position_Z=111
x050076_g_SceneID=2
x050076_g_AccomplishNPC_Name="A Nguy�t"
--MisDescEnd
