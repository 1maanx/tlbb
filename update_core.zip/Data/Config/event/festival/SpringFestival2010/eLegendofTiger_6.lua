--MisDescBegin
x050077_g_ScriptId = 050077
x050077_g_MissionId = 1184
x050077_g_MissionKind = 13
x050077_g_MissionLevel = 10000
x050077_g_IfMissionElite = 0
x050077_g_MissionName="#{SXGS_091105_32}"
x050077_g_MissionTarget="#{SXGS_091105_37}"
x050077_g_IsMissionOkFail = 0
x050077_g_Custom1 = {{id = "�� t�m ���c Sinh Ti�u H�",num = 1}}
x050077_g_Custom2 = {{id = "�� t�m th�y v�t t�ch",num = 1}}
x050077_g_MissionRound = 387
--MisDescEnd
