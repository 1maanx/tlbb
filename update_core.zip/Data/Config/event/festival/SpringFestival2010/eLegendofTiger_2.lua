--MisDescBegin
x050073_g_ScriptId = 050073
x050073_g_MissionId = 1180
x050073_g_MissionKind = 13
x050073_g_MissionLevel = 10000
x050073_g_IfMissionElite = 0
x050073_g_MissionName="#{SXGS_091105_11}"
x050073_g_MissionTarget="#{SXGS_091105_14}"
x050073_g_IsMissionOkFail = 0		
x050073_g_Custom = {{id = "�� t�m th�y Ch�u Thi�n S�",num = 1}}
x050073_g_MissionRound = 387
x050073_g_Position_X=160
x050073_g_Position_Z=134
x050073_g_SceneID=0
x050073_g_AccomplishNPC_Name="Ch�u Thi�n S�"
--MisDescEnd
