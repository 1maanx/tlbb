--MisDescBegin
x809445_g_ScriptId = 809445
x809445_g_MissionId = 1136
x809445_g_MissionName = "��n Hoa ��m Tr�ng"
x809445_g_Position_X = 97.6117
x809445_g_Position_Z = 204.6548
x809445_g_SceneID = 1
x809445_g_AccomplishNPC_Name = "T� Th�c" 	
x809445_g_MissionKind = 12 
x809445_g_MissionLevel = 10000
x809445_g_MissionTarget = "#{YMYXH_20100901_16}"
x809445_g_IsMissionOkFail	= 0
x809445_g_Custom1	= { {id="�� th� trung thu hoa ��ng",num=1} }
x809445_g_Custom2	= { {id="�� nh�n ���c linh c�m ph� t� m�i",num=1} }
--MisDescEnd
