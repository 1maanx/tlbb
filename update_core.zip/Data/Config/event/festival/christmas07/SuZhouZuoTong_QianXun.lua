--MisDescBegin
x229024_g_ScriptId	= 229024
x229024_g_Position_X=129.2676
x229024_g_Position_Z=213.0914
x229024_g_SceneID=1
x229024_g_AccomplishNPC_Name="T� аng"
x229024_g_MissionId			= 421
x229024_g_MissionIdNext	= 421
x229024_g_Name			= "T� аng"
x229024_g_MissionKind			= 12
x229024_g_MissionLevel		= 10
x229024_g_IfMissionElite	= 0
x229024_g_IsMissionOkFail	= 0		--�����ĵ�0λ
x229024_g_MissionName			= "Thi�n t�m"
x229024_g_MissionInfo			= "#{QX_20071129_026}"
x229024_g_MissionTarget		= "#{QX_20071129_025}"
x229024_g_ContinueInfo		= "#{QIANXUN_INFO_19}"
x229024_g_MissionComplete	= "#{QX_20071129_039}"
x229024_g_MaxRound	= 10
x229024_g_ControlScript		= 001066
--MisDescEnd
