--MisDescBegin
x808327_g_ScriptId 			= 808327
x808327_g_MissionId			= 1138
x808327_g_NextScriptId		= 808328
x808327_g_Position_X = 189.2887
x808327_g_Position_Z = 173.7257
x808327_g_SceneID = 1
x808327_g_AccomplishNPC_Name = "Tr� Ho�"
x808327_g_Name 					= "Tr� Ho�"
x808327_g_MissionKind			= 12
x808327_g_MissionLevel		= 10000
x808327_g_IfMissionElite	= 0
x808327_g_MissionName			= "#{ZQJ_100901_36}"
x808327_g_MissionInfo			= "#{ZQJ_100901_29}"
x808327_g_MissionTarget		= "#{ZQJ_100901_28}"
x808327_g_MissionComplete	= "#{ZQJ_100901_30}"
x808327_g_Custom	= { {id="�� t�ng b�nh trung thu", num=1} }
--MisDescEnd
