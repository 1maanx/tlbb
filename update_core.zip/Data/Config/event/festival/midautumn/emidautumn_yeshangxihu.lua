--MisDescBegin
x808328_g_ScriptId = 808328
x808328_g_MissionId			= 1139
x808328_g_Position_X = 280.2300
x808328_g_Position_Z = 183.9060
x808328_g_SceneID=121
x808328_g_AccomplishNPC_Name="T� Th�c"
x808328_g_Name				= "Tr� Ho�"
x808328_g_MissionKind		= 12
x808328_g_MissionLevel		= 10000
x808328_g_IfMissionElite	= 0
x808328_g_MissionName		= "#{ZQJ_100901_37}"
x808328_g_MissionInfo		= "#{ZQJ_100901_32}"
x808328_g_MissionTarget		= "#{ZQJ_100901_31}"
x808328_g_ContinueInfo		= "#{ZQJ_100901_33}"
x808328_g_MissionComplete	= "#{ZQJ_100901_34}"
x808328_g_Custom	= { {id="�� t�m th�y T� Th�c � T�y H�",num=1} }
x808328_g_ControlScript		= 001066
--MisDescEnd
