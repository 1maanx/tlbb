--MisDescBegin
x050019_g_ScriptId = 050019
x050019_g_MissionId = 132
x050019_g_Name	="L�ng Ch�n"
x050019_g_MissionKind = 3
x050019_g_MissionLevel = 10
x050019_g_IfMissionElite = 0
x050019_g_MissionName="#{ZQSY_2007912_001}"
x050019_g_MissionInfo="#{ZQSY_2007912_002}"
x050019_g_MissionTarget="#{ZQSY_2007912_003}"
x050019_g_MissionContinue="#{ZQSY_2007912_004}"
x050019_g_MissionComplete="#{ZQSY_2007912_005}"
x050019_g_Custom	= { {id="�� �t T�m T� Li�n K�t",num=1} }
x050019_g_IsMissionOkFail = 0
--MisDescEnd
