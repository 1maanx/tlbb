--MisDescBegin
x050018_g_ScriptId = 050018
x050018_g_MissionId = 131
x050018_g_Name	="L�ng Ch�n"
x050018_g_MissionKind = 3
x050018_g_MissionLevel = 10
x050018_g_IfMissionElite = 0
x050018_g_MissionName="#{ZQSY_2007912_007}"
x050018_g_MissionInfo="#{ZQSY_2007912_008}"
x050018_g_MissionTarget="#{ZQSY_2007912_009}"
x050018_g_MissionContinue="#{ZQSY_2007912_010}"
x050018_g_MissionComplete="#{ZQSY_2007912_011}"
x050018_g_Custom	= { {id="�� ph�ng Trung Thu Vui V�",num=1} }
x050018_g_IsMissionOkFail = 0
--MisDescEnd
