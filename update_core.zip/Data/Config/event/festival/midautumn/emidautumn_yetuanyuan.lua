--MisDescBegin
x808326_g_ScriptId 			= 808326
x808326_g_MissionId			= 1137
x808326_g_NextScriptId		= 808327
x808326_g_Position_X = 189.2887
x808326_g_Position_Z = 173.7257
x808326_g_SceneID = 1
x808326_g_AccomplishNPC_Name = "Tr� Ho�"
x808326_g_Name 				= "T� Th�c"
x808326_g_MissionKind		= 12
x808326_g_MissionLevel		= 10000
x808326_g_IfMissionElite	= 0
x808326_g_MissionName		= "#{ZQJ_100901_03}"
x808326_g_MissionInfo		= "#{ZQJ_100901_26}"
x808326_g_MissionTarget		= "#{ZQJ_100901_25}"
x808326_g_MissionComplete	= "#{ZQJ_100901_27}"
x808326_g_Custom	= { {id="�� t�m th�y Tr� H�a", num=1} }
--MisDescEnd
