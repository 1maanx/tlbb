--MisDescBegin
x809335_g_ScriptId = 809335
x809335_g_MissionId = 1135
x809335_g_MissionKind = 1
x809335_g_MissionLevel = 10000
x809335_g_IfMissionElite = 0
x809335_g_IsMissionOkFail = 0		--�����ĵ�0λ
x809335_g_MissionList = {
1131,
1132,
1133,
1134,
1135,
}
x809335_g_ItemSend = 40004538
x809335_g_ItemCheck = 40004539
x809335_g_ItemList = {
{40004560, 40004561},
{40004561, 40004562},
{40004562, 40004563},
{40004563, 40004564},
{40004564, 40004565},
{40004565, 40004566},
{40004566, 40004567},
{40004567, 40004568},
{40004568, -1},
}
x809335_g_MissionName="#{TJRW_100511_42}"
x809335_g_MissionInfo=""
x809335_g_MissionTarget="#{TJRW_100511_28}"
x809335_g_ContinueInfo="#{TJRW_100511_34}"
x809335_g_MissionComplete="#{TJRW_100511_33}"
x809335_g_Name = "Ng�y Tam Gia"
x809335_g_AccomplishNPC_Name			= "Ng�y Tam Gia"
x809335_g_SceneID						= 1
x809335_g_Position_X					= 230
x809335_g_Position_Z					= 152
x809335_g_ItemBonus={{id=20700010,num=6}}
x809335_g_Custom = { {id="�� gi�i �c s�",num=1} }
--MisDescEnd
