--MisDescBegin
x808167_g_ScriptId	= 808167
x808167_g_MissionId	= 1235
x808167_g_MissionLevel	= 10000
x808167_g_MissionKind	= 13
x808167_g_MissionName	= "Tri�t l�"
x808167_g_MissionInfo	= "#{STJB_100518_175}"
x808167_g_MissionTarget	= "#{STJB_100518_175}"
x808167_g_ContinueInfo	= "#{STJB_100518_35}"
x808167_g_MissionComplete = "#{STJB_100518_43}"
x808167_g_Param_IsMissionOkFail	= 0						--0�ţ���ǰ�����Ƿ����(0δ��ɣ�1���)
x808167_g_Custom	= { {id="�� l�ng nghe xong",num=1} }
--MisDescEnd
