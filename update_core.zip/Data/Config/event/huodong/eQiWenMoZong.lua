--MisDescBegin
x808134_g_ScriptId = 808134
x808134_g_AccomplishNPC_Name="L߽ng ��o S�"
x808134_g_MissionId = 1157
x808134_g_Name	="H�a Nguy�n Th�"
x808134_g_MissionKind = 12
x808134_g_MissionLevel = 10000
x808134_g_IfMissionElite = 0
x808134_g_MissionName="#{ZXCM_090602_07}"
x808134_g_MissionTarget="#{ZXCM_090602_10}"
x808134_g_Custom1	= { {id="�� t�m H�a Nguy�n Th�",num=1} }
x808134_g_Custom2	= { {id="�� t�m ���c manh m�i",num=1} }
x808134_g_IsMissionOkFail = 1		--�����ĵ�0λ
--MisDescEnd
