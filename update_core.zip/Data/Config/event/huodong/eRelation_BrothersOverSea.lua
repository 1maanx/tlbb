--MisDescBegin
x808152_g_ScriptId = 808152
x808152_g_MissionId = 1221
x808152_g_MissionName="#{STJB_100518_1}"
x808152_g_AccomplishNPC_Name=" " 
x808152_g_MissionKind = 11
x808152_g_MissionLevel = 10000
x808152_g_MissionTarget="#{STJB_100518_200}"
x808152_g_Custom	= { {id="�� tr�ng hoa Kim Lan",num=1} }
x808152_g_ContinueInfo="#{STJB_100518_200}"
x808152_g_MissionComplete="#{STJB_100518_23}"
--MisDescEnd
