--MisDescBegin
x808166_g_ScriptId	= 808166
x808166_g_MissionId	= 1234
x808166_g_MissionLevel	= 10000
x808166_g_MissionKind	= 13
x808166_g_MissionName	= "��a th�"
x808166_g_MissionInfo	= "  "
x808166_g_MissionTarget = "%f"
x808166_g_ContinueInfo	= ""
x808166_g_MissionComplete = "#{STJB_100518_43}"
x808166_g_Param_IsMissionOkFail	= 0						--0�ţ���ǰ�����Ƿ����(0δ��ɣ�1���)
x808166_g_Custom	= { {id="�� g�i th�",num=1} }
x808166_g_FormatList = {
"#{STJB_100518_249}#R%n#{STJB_100518_250}",
}
x808166_g_StrForePart=5
--MisDescEnd
