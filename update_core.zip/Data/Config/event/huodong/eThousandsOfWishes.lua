--MisDescBegin
x808131_g_ScriptId = 808131
x808131_g_Position_X=186
x808131_g_Position_Z=182
x808131_g_SceneID=1
x808131_g_AccomplishNPC_Name="L߽ng ��o S�"
x808131_g_MissionId = 1161
x808131_g_Name	="L߽ng ��o S�"
x808131_g_MissionKind = 12
x808131_g_MissionLevel = 10000
x808131_g_IfMissionElite = 0
x808131_g_MissionName="#{SQXY_09061_4}"
x808131_g_MissionInfo="#{SQXY_09061_39}"
x808131_g_MissionTarget="#{SQXY_09061_11}"
x808131_g_ContinueInfo="#{SQXY_09061_19}"
x808131_g_MissionComplete = "#{SQXY_09061_36}"
x808131_g_IsMissionOkFail=0
x808131_g_ItemBonus={{id=20502010,num=1}} --��Ը�� ����
x808131_g_Custom	= { {id="H�a h�n v�i H�a Nguy�n Th�",num=5} }
--MisDescEnd
