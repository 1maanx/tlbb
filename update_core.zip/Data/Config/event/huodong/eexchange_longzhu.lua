--MisDescBegin
x808058_g_ScriptId = 808058
x808058_g_ExchangeLongzhu_Active = 1
x808058_g_LongpaiId = 30505092
x808058_g_Longpai75Id =	30505907
x808058_g_LongzhuList = { 30505136, 30505137, 30505138, 30505139, 30505140, 30505141, 30505142 }
--MisDescEnd
