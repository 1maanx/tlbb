--MisDescBegin
x808149_g_ScriptId = 808149
x808149_g_MissionId = 1124
x808149_g_MissionKind = 12
x808149_g_MissionLevel = 10000
x808149_g_IfMissionElite = 0
x808149_g_MissionName="#{QLYX_100517_24}"
x808149_g_MissionTarget="#{QLYX_100517_14}#{QLYX_100517_45}"
x808149_g_IsMissionOkFail = 0	
x808149_g_MissionLimitTime = 15*60*1000
x808149_g_Custom = {{id = "�� t�m th�y d�a h�u",num = 1}}
--MisDescEnd
