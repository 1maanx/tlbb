--MisDescBegin
x809429_g_ScriptId = 809429  
x809429_g_MissionId = 1195
x809429_g_MissionName="Th�m tung c�a T� Duy�n T�"
x809429_g_Position_X=230.7304
x809429_g_Position_Z=152.4640
x809429_g_SceneID=1
x809429_g_AccomplishNPC_Name="Ng�y Tam Gia" 
x809429_g_AcceptNPC_SceneID=1
x809429_g_MissionKind = 12   
x809429_g_MissionLevel = 10000
x809429_g_MissionTarget="#{SYC_100521_18}"		
x809429_g_MoneyBonus=10
x809429_g_Custom	= { {id="�� t�m ���c b�ch Hi�u Ch�n Nh�n � d� h�i:",num=1} }
--MisDescEnd
