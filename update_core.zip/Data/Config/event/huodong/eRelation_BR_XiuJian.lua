--MisDescBegin
x808159_g_ScriptId	= 808159
x808159_g_MissionId	= 1227
x808159_g_MissionLevel	= 10000
x808159_g_MissionKind	= 11
x808159_g_MissionName	= "T�a c�nh"
x808159_g_MissionInfo	= "#{STJB_100518_27}"
x808159_g_MissionTarget	= "#{STJB_100518_167}"
x808159_g_ContinueInfo	= "#{STJB_100518_28}"
x808159_g_MissionComplete = "#{STJB_100518_43}"
x808159_g_Param_IsMissionOkFail	= 0						--0�ţ���ǰ�����Ƿ����(0δ��ɣ�1���)
x808159_g_Custom	= { {id="�� t�a",num=1} }
--MisDescEnd
