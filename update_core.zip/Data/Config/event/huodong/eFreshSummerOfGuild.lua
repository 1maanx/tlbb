--MisDescBegin
x808150_g_ScriptId = 808150
x808150_g_MissionId = 1125
x808150_g_MissionKind = 50
x808150_g_MissionLevel = 10000
x808150_g_IfMissionElite = 0
x808150_g_MissionName="#{QLYX_100517_28}"
x808150_g_MissionTarget="#{QLYX_100517_36}#{QLYX_100517_45}"
x808150_g_IsMissionOkFail = 0	
x808150_g_MissionLimitTime = 15*60*1000
x808150_g_Custom = {{id = "�� t�m th�y d�a h�u",num = 1}}
--MisDescEnd
