--MisDescBegin
x809336_g_ScriptId = 809336
x809336_g_MissionId = 1131
x809336_g_MissionKind = 1
x809336_g_MissionLevel = 10000
x809336_g_IfMissionElite = 0
x809336_g_IsMissionOkFail = 0		--�����ĵ�0λ
x809336_g_MissionName="#{TJRW_100511_38}"
x809336_g_MissionInfo=""
x809336_g_MissionTarget="%f"
x809336_g_ContinueInfo="#{TJRW_100511_34}"
x809336_g_MissionComplete="#{TJRW_100511_33}"
x809336_g_FormatList = {
"#{TJRW_100511_7}%s#{TJRW_100511_95}",
}
x809336_g_StrForePart = 4
x809336_g_StrList = {"#{TJRW_100511_43}", 
"#{TJRW_100511_44}", 
"#{TJRW_100511_45}", 
"#{TJRW_100511_47}", 
"#{TJRW_100511_50}",
"#{TJRW_100511_51}",
"#{TJRW_100511_52}",
"#{TJRW_100511_46}", 
"#{TJRW_100511_49}", 
"#{TJRW_100511_48}", 
}
x809336_g_Name = "Ng�y Tam Gia"
x809336_g_AccomplishNPC_Name			= "Ng�y Tam Gia"
x809336_g_SceneID						= 1
x809336_g_Position_X					= 230
x809336_g_Position_Z					= 152
x809336_g_Custom = { {id="�� m� ra b�c �nh th�n b�",num=1} }
x809336_g_ItemBonus={ {id=20700010,num=2} }
--MisDescEnd
