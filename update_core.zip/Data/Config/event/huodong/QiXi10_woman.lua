--MisDescBegin
x808321_g_ScriptId = 808321
x808321_g_AccomplishNPC_Name="Kh�u B�ch Уc"
x808321_g_Position_X=177
x808321_g_Position_Z=102
x808321_g_SceneID=0
x808321_g_MissionId = 1206
x808321_g_Name	="Kh�u B�ch Уc"
x808321_g_MissionKind = 11
x808321_g_MissionLevel = 10000
x808321_g_IfMissionElite = 0
x808321_g_MissionName="#{FZY_100803_1}"
x808321_g_MissionTarget="#{FZY_100803_10}"
x808321_g_Custom	= {{id="�� t�ng ���c t� t�nh",num=1}}
x808321_g_IsMissionOkFail = 1		--�����ĵ�0λ
--MisDescEnd
