--MisDescBegin
x808320_g_ScriptId = 808320
x808320_g_AccomplishNPC_Name="Kh�u B�ch Уc"
x808320_g_Position_X=177
x808320_g_Position_Z=102
x808320_g_SceneID=0
x808320_g_MissionId = 1205
x808320_g_Name	="Kh�u B�ch Уc"
x808320_g_MissionKind = 11
x808320_g_MissionLevel = 10000
x808320_g_IfMissionElite = 0
x808320_g_MissionName="#{FZY_100803_3}"
x808320_g_MissionTarget="#{FZY_100803_20}"
x808320_g_Custom	= { {id="�� t� t�nh",num=1}}
x808320_g_IsMissionOkFail = 1		--�����ĵ�0λ
--MisDescEnd
