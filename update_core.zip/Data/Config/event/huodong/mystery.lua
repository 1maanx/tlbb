--MisDescBegin
x809331_g_ScriptId = 809331
x809331_g_MissionId = 1131
x809331_g_MissionKind = 1
x809331_g_MissionLevel = 10000
x809331_g_IfMissionElite = 0
x809331_g_IsMissionOkFail = 0		--�����ĵ�0λ
x809331_g_MissionName="#{TJRW_100511_38}"
x809331_g_MissionInfo=""
x809331_g_MissionTarget="%f"
x809331_g_ContinueInfo="#{TJRW_100511_34}"
x809331_g_MissionComplete="#{TJRW_100511_33}"
x809331_g_FormatList = {
"#{TJRW_100511_7}%s#{TJRW_100511_95}",
}
x809331_g_StrForePart = 4
x809331_g_StrList = {"#{TJRW_100511_43}", 
"#{TJRW_100511_44}", 
"#{TJRW_100511_45}", 
"#{TJRW_100511_47}", 
"#{TJRW_100511_50}",
"#{TJRW_100511_51}",
"#{TJRW_100511_52}",
"#{TJRW_100511_46}", 
"#{TJRW_100511_49}", 
"#{TJRW_100511_48}", 
}
x809331_g_Name = "Ng�y Tam Gia"
x809331_g_AccomplishNPC_Name			= "Ng�y Tam Gia"
x809331_g_SceneID						= 1
x809331_g_Position_X					= 230
x809331_g_Position_Z					= 152
x809331_g_Custom = { {id="�� m� ra b�c �nh th�n b�",num=1} }
--MisDescEnd
