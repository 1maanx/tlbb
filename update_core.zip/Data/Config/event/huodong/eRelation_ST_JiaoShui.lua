--MisDescBegin
x808163_g_ScriptId	= 808163
x808163_g_MissionId	= 1231
x808163_g_MissionLevel	= 10000
x808163_g_MissionKind	= 13
x808163_g_MissionName	= "#{STJB_100518_50}"
x808163_g_MissionInfo	= "  "
x808163_g_MissionTarget	= "#{STJB_100518_179}"
x808163_g_ContinueInfo	= "#{STJB_100518_179}"
x808163_g_MissionComplete = "#{STJB_100518_43}"
x808163_g_Param_IsMissionOkFail	= 0						--0�ţ���ǰ�����Ƿ����(0δ��ɣ�1���)
x808163_g_Custom	= {{id="�� t߾i n߾c 10 l�n",num=1}}
--MisDescEnd
