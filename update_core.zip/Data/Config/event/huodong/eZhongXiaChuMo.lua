--MisDescBegin
x808133_g_ScriptId = 808133
x808133_g_Position_X=184
x808133_g_Position_Z=180
x808133_g_SceneID=1
x808133_g_AccomplishNPC_Name="L߽ng ��o S�"
x808133_g_MissionKind = 13
x808133_g_MissionLevel = 10000
x808133_g_IfMissionElite = 0
x808133_g_MissionName="#{ZXCM_090602_04}"
x808133_g_MissionInfo="#{ZXCM_090602_06}"
--MisDescEnd
