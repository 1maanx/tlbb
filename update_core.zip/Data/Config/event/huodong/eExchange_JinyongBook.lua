--MisDescBegin
x808035_g_ScriptId = 808035
x808035_g_ExchangeJinyongBook_Active = 1
--MisDescEnd
