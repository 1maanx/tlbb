--MisDescBegin
x808158_g_ScriptId	= 808158
x808158_g_MissionId	= 1226
x808158_g_MissionLevel	= 10000
x808158_g_MissionKind	= 11
x808158_g_MissionName	= "Tri�t l�"
x808158_g_MissionInfo	= "#{STJB_100518_175}"
x808158_g_MissionTarget	= "#{STJB_100518_175}"
x808158_g_ContinueInfo	= "#{STJB_100518_35}"
x808158_g_MissionComplete = "#{STJB_100518_43}"
x808158_g_Param_IsMissionOkFail	= 0						--0�ţ���ǰ�����Ƿ����(0δ��ɣ�1���)
x808158_g_Custom	= { {id="�� l�ng nghe xong",num=1} }
--MisDescEnd
