--MisDescBegin
x809441_g_ScriptId = 809441
x809441_g_MissionId = 1170
x809441_g_MissionLevel = 10000
x809441_g_MissionTarget		= "#{DWJ_100603_53}"
x809441_g_MissionKind = 3
x809441_g_IfMissionElite = 0
x809441_g_MissionName="#{DWJ_100603_1}"
x809441_g_Custom	= {id="�� th�m th�nh ho�n c�nh",num=8}
--MisDescEnd
