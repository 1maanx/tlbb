--MisDescBegin
x808157_g_ScriptId	= 808157
x808157_g_MissionId	= 1225
x808157_g_MissionLevel	= 10000
x808157_g_MissionKind	= 11
x808157_g_MissionName	= "��a th�"
x808157_g_MissionInfo	= "  "
x808157_g_MissionTarget = "%f"
x808157_g_ContinueInfo	= ""
x808157_g_MissionComplete = "#{STJB_100518_43}"
x808157_g_Param_IsMissionOkFail	= 0						--0�ţ���ǰ�����Ƿ����(0δ��ɣ�1���)
x808157_g_Custom	= { {id="�� g�i th�",num=1} }
x808157_g_FormatList = {
"#{STJB_100518_249}#R%n#{STJB_100518_250}",
}
x808157_g_StrForePart=5
--MisDescEnd
