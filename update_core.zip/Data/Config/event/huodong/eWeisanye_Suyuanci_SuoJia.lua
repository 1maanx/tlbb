--MisDescBegin
x809430_g_ScriptId = 809430  --
x809430_g_MissionId = 1196
x809430_g_MissionName="S�ch gi� c�a T� Duy�n T�"
x809430_g_Position_X=230.7304
x809430_g_Position_Z=152.4640
x809430_g_SceneID=1
x809430_g_AccomplishNPC_Name="Ng�y Tam Gia" 
x809430_g_AcceptNPC_SceneID=1
x809430_g_MissionKind = 12   --
x809430_g_MissionLevel = 10000
x809430_g_MissionTarget="#{SYC_100521_30}"		--����Ŀ��
x809430_g_MoneyBonus=10
x809430_g_Custom	= { {id="�� gian 1 v�n kim cho B�ch Hi�u Ch�n Nh�n",num=1} }
--MisDescEnd
