--MisDescBegin
x809323_g_ScriptId = 809323
x809323_g_MissionId = 1194
x809323_g_MissionKind = 11
x809323_g_MissionLevel = 30
x809323_g_IfMissionElite = 0
x809323_g_IsMissionOkFail = 0		--�����ĵ�0λ
x809323_g_MissionName="#{LYGL_100107_15}"
x809323_g_MissionInfo="#{LYGL_100107_16}"
x809323_g_MissionTarget="#{LYGL_100107_32}"
x809323_g_ContinueInfo="#{TM_20080313_08}"
x809323_g_MissionComplete="#{TM_20080313_08}"
x809323_g_Name = "Qu�ch Thi�n T�n"
x809323_g_Custom = { {id="�� thu th�p [D�ng kh�]",num=10} }
--MisDescEnd
