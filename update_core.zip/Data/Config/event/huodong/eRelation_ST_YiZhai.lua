--MisDescBegin
x808169_g_ScriptId = 808169
x808169_g_MissionId = 1237
x808169_g_MissionName="Di chuy�n"
x808169_g_AccomplishNPC_Name=" " 
x808169_g_MissionKind = 13
x808169_g_MissionLevel = 10000
x808169_g_MissionTarget="#{STJB_100518_31}"
x808169_g_ContinueInfo="#{STJB_100518_31}"
x808169_g_MissionComplete="#{STJB_100518_43}"
x808169_g_Custom	= { {id="�� tr�ng m�m ��o L�",num=1} }
--MisDescEnd
