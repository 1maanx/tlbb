--MisDescBegin
x808036_g_ScriptId = 808036
x808036_g_ExchangeXinfaBook_Active = 1
x808036_g_NeedItemCount_Miji = 7
x808036_g_NeedItemCount_Yaojue = 8
x808036_g_NeedItemID = 30505078
--MisDescEnd
