--MisDescBegin
x809333_g_ScriptId = 809333
x809333_g_MissionId = 1133
x809333_g_MissionKind = 1
x809333_g_MissionLevel = 10000
x809333_g_IfMissionElite = 0
x809333_g_IsMissionOkFail = 0		--�����ĵ�0λ
x809333_g_MissionList = {
1131,
1132,
1133,
1134,
1135,
}
x809333_g_ItemIndex = 40004559 
x809333_g_ItemList = {
{40004560, 40004561, 0},
{40004561, 40004562, 1},
{40004562, 40004563, 1},
{40004563, 40004564, 2},
{40004564, 40004565, 2},
{40004565, 40004566, 3},
{40004566, 40004567, 3},
{40004567, 40004568, 4},
}
x809333_g_MissionName="T�m Ng߶i C� Duy�n"
x809333_g_MissionInfo=""
x809333_g_MissionTarget="#{TJRW_100511_20}"
x809333_g_ContinueInfo="#{TJRW_100511_34}"
x809333_g_MissionComplete="#{TJRW_100511_33}"
x809333_g_Name = "Ng�y Tam Gia"
x809333_g_AccomplishNPC_Name			= "Ng�y Tam Gia"
x809333_g_SceneID						= 1
x809333_g_Position_X					= 230
x809333_g_Position_Z					= 152
x809333_g_ItemBonus={{id=20700010,num=1}}
x809333_g_Custom = { {id="�� t�m ���c ng߶i h�u duy�n",num=1} }
--MisDescEnd
