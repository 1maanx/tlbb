--MisDescBegin
x808140_g_ScriptId = 808140
x808140_g_Position_X=239
x808140_g_Position_Z=101
x808140_g_SceneID=1
x808140_g_AccomplishNPC_Name="Vi ��i th�c"
x808140_g_MissionId = 1148
x808140_g_Name	="Vi ��i th�c"
x808140_g_MissionKind = 12
x808140_g_MissionLevel = 10000
x808140_g_IfMissionElite = 0
x808140_g_MissionName="#{DSCJ_090414_02}"
x808140_g_MissionTarget="#{DSCJ_090414_16}"
x808140_g_IsMissionOkFail = 0		--�����ĵ�0λ
x808140_g_MissionLimitTime = 23*60*60*1000   --23Сʱ
x808140_g_StopWatch_Pause_Flag = 57
x808140_g_Custom = {{id = "Ch� �i�m th�ch th�nh kim ho�n th�nh",num = 1}}
--MisDescEnd
