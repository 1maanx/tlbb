--MisDescBegin
x809334_g_ScriptId = 809334
x809334_g_MissionId = 1134
x809334_g_MissionKind = 1
x809334_g_MissionLevel = 10000
x809334_g_IfMissionElite = 0
x809334_g_IsMissionOkFail = 0		--�����ĵ�0λ
x809334_g_MissionName="#{TJRW_100511_41}"
x809334_g_MissionInfo=""
x809334_g_MissionTarget="%f"
x809334_g_Name = "Ng�y Tam Gia"
x809334_g_AccomplishNPC_Name			= "Ng�y Tam Gia"
x809334_g_SceneID						= 1
x809334_g_Position_X					= 230
x809334_g_Position_Z					= 152
x809334_g_ContinueInfo="#{TJRW_100511_34}"
x809334_g_MissionComplete="#{TJRW_100511_33}"
x809334_g_FormatList = {
"#{TJRW_100511_22}%s,#{TJRW_100511_96}",
}
x809334_g_StrForePart = 4
x809334_g_StrList = {"#{TJRW_100511_60}", 
"#{TJRW_100511_61}", 
"#{TJRW_100511_62}", 
"#{TJRW_100511_63}", 
"#{TJRW_100511_64}", 
"#{TJRW_100511_65}", 
"#{TJRW_100511_66}", 
"#{TJRW_100511_67}"
}
x809334_g_ItemBonus={{id=20700010,num=1} }	
x809334_g_Custom = { {id="�� �n ",num=1} }
--MisDescEnd
