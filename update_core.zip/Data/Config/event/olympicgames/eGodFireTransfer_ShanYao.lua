--MisDescBegin
x808097_g_ScriptId	= 808097
x808097_g_Position_X=255.9010
x808097_g_Position_Z=126.7257
x808097_g_SceneID=2
x808097_g_AccomplishNPC_Name="Th�n T�nh"
x808097_g_MissionId			= 1003
x808097_g_MissionIdNext	= 1004
x808097_g_AcceptNPC_SceneID	=	30
x808097_g_Name 					= "T� Phi"
x808097_g_MissionKind			= 13
x808097_g_MissionLevel		= 10
x808097_g_IfMissionElite	= 0
x808097_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x808097_g_MissionName			= "T�a s�ng Th�nh H�a"
x808097_g_MissionInfo			= "#{XSHCD_20080418_014}"
x808097_g_MissionTarget		= "#{XSHCD_20080418_044}"
x808097_g_ContinueInfo		= "#{XSHCD_20080418_015}"
x808097_g_MissionComplete	= "#{XSHCD_20080418_016}"
x808097_g_MaxRound	= 3
x808097_g_ControlScript		= 001066
x808097_g_Custom	= { {id="�� giao �u�c cho ��i L� Th�n T�nh",num=1} }
--MisDescEnd
