--MisDescBegin
x808098_g_ScriptId	= 808098
x808098_g_Position_X=255.9010
x808098_g_Position_Z=126.7257
x808098_g_SceneID=2
x808098_g_AccomplishNPC_Name="Th�n T�nh"
x808098_g_MissionId			= 1004
x808098_g_MissionIdNext	= 1005
x808098_g_Name 					= "Th�n T�nh"
x808098_g_MissionKind			= 13
x808098_g_MissionLevel		= 10
x808098_g_IfMissionElite	= 0
x808098_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x808098_g_MissionName			= "Th� thao th� gi�i"
x808098_g_MissionInfo			= "#{XSHCD_20080418_017}"
x808098_g_MissionTarget		= "#{XSHCD_20080418_045}"
x808098_g_ContinueInfo		= "#{XSHCD_20080418_018}"
x808098_g_MissionComplete	= "#{XSHCD_20080418_019}"
x808098_g_MaxRound	= 3
x808098_g_ControlScript		= 001066
x808098_g_Custom	= { {id="�� tr� l�i ��ng li�n ti�p 5 c�u h�i c�a Th�n T�nh",num=1} }
--MisDescEnd
