--MisDescBegin
x808105_g_ScriptId	= 808105
x808105_g_Position_X=91.1844
x808105_g_Position_Z=84.0730
x808105_g_SceneID=1
x808105_g_AccomplishNPC_Name="Th�nh ho� ��n"
x808105_g_MissionId			= 1011
x808105_g_MissionIdNext	= 1011
x808105_g_AcceptNPC_SceneID	=	18
x808105_g_Name 					= "Ch�u V� U�"
x808105_g_MissionKind			= 13
x808105_g_MissionLevel		= 10
x808105_g_IfMissionElite	= 0
x808105_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x808105_g_MissionName			= "V�nh h�ng Th�nh  H�a"
x808105_g_MissionInfo			= "#{XSHCD_20080418_038}"
x808105_g_MissionTarget		= "#{XSHCD_20080418_052}"
x808105_g_ContinueInfo		= "#{XSHCD_20080418_039}"
x808105_g_MissionComplete	= "#{XSHCD_20080418_040}"
x808105_g_MaxRound	= 3
x808105_g_ControlScript		= 001066
x808105_g_Custom	= { {id="�� giao �u�c cho T� Ch�u Th�nh H�a ��n",num=1} }
--MisDescEnd
