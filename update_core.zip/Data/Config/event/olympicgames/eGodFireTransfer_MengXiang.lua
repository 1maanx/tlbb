--MisDescBegin
x808102_g_ScriptId	= 808102
x808102_g_Position_X=111.0545
x808102_g_Position_Z=211.7807
x808102_g_SceneID=0
x808102_g_AccomplishNPC_Name="Y�n Thanh"
x808102_g_MissionId			= 1008
x808102_g_MissionIdNext	= 1009
x808102_g_Name 					= "Y�n Thanh"
x808102_g_MissionKind			= 13
x808102_g_MissionLevel		= 10
x808102_g_IfMissionElite	= 0
x808102_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x808102_g_MissionName			= "��c m� th� thao"
x808102_g_MissionInfo			= "#{XSHCD_20080418_029}"
x808102_g_MissionTarget		= "#{XSHCD_20080418_049}"
x808102_g_ContinueInfo		= "#{XSHCD_20080418_030}"
x808102_g_MissionComplete	= "#{XSHCD_20080418_031}"
x808102_g_MaxRound	= 3
x808102_g_ControlScript		= 001066
x808102_g_Custom	= { {id="�� tr� l�i ��ng li�n ti�p 5 c�u h�i c�a Y�n Thanh",num=1} }
--MisDescEnd
