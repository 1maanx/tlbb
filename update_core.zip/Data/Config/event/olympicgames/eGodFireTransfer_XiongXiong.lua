--MisDescBegin
x808099_g_ScriptId	= 808099
x808099_g_Position_X=207.4352
x808099_g_Position_Z=49.5008
x808099_g_SceneID=24
x808099_g_AccomplishNPC_Name="�ao Nghi�u"
x808099_g_MissionId			= 1005
x808099_g_MissionIdNext	= 1006
x808099_g_AcceptNPC_SceneID	=	2
x808099_g_Name 					= "Th�n T�nh"
x808099_g_MissionKind			= 13
x808099_g_MissionLevel		= 10
x808099_g_IfMissionElite	= 0
x808099_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x808099_g_MissionName			= "R�c l�a Th�nh H�a"
x808099_g_MissionInfo			= "#{XSHCD_20080418_020}"
x808099_g_MissionTarget		= "#{XSHCD_20080418_046}"
x808099_g_ContinueInfo		= "#{XSHCD_20080418_021}"
x808099_g_MissionComplete	= "#{XSHCD_20080418_022}"
x808099_g_MaxRound	= 3
x808099_g_ControlScript		= 001066
x808099_g_Custom	= { {id="Ta �� giao �u�c cho Nh� H�i �ao Nghi�u",num=1} }
--MisDescEnd
