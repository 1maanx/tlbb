--MisDescBegin
x808100_g_ScriptId	= 808100
x808100_g_Position_X=207.4352
x808100_g_Position_Z=49.5008
x808100_g_SceneID=24
x808100_g_AccomplishNPC_Name="�ao Nghi�u"
x808100_g_MissionId			= 1006
x808100_g_MissionIdNext	= 1007
x808100_g_Name 					= "�ao Nghi�u"
x808100_g_MissionKind			= 13
x808100_g_MissionLevel		= 10
x808100_g_IfMissionElite	= 0
x808100_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x808100_g_MissionName			= "Th�nh H�a chuy�n ti�p nhanh h�n"
x808100_g_MissionInfo			= "#{XSHCD_20080418_023}"
x808100_g_MissionTarget		= "#{XSHCD_20080418_047}"
x808100_g_ContinueInfo		= "#{XSHCD_20080418_024}"
x808100_g_MissionComplete	= "#{XSHCD_20080418_025}"
x808100_g_MaxRound	= 3
x808100_g_ControlScript		= 001066
x808100_g_Custom	= { {id="�� ��nh b�i B�i C�u",num=5}, {id="�� ��nh b�i Ti�u Nh� Nh�",num=1} }
--MisDescEnd
