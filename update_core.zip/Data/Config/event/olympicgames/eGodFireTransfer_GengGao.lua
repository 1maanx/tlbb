--MisDescBegin
x808096_g_ScriptId	= 808096
x808096_g_Position_X=164.5310
x808096_g_Position_Z=262.5004
x808096_g_SceneID=30
x808096_g_AccomplishNPC_Name="T� Phi"
x808096_g_MissionId			= 1002
x808096_g_MissionIdNext	= 1003
x808096_g_Name 					= "T� Phi"
x808096_g_MissionKind			= 13
x808096_g_MissionLevel		= 10
x808096_g_IfMissionElite	= 0
x808096_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x808096_g_MissionName			= "Th�nh ho� chuy�n ti�p l�n cao h�n"
x808096_g_MissionInfo			= "#{XSHCD_20080418_011}"
x808096_g_MissionTarget		= "#{XSHCD_20080418_043}"
x808096_g_ContinueInfo		= "#{XSHCD_20080418_012}"
x808096_g_MissionComplete	= "#{XSHCD_20080418_013}"
x808096_g_MaxRound	= 3
x808096_g_ControlScript		= 001066
x808096_g_Custom	= { {id="�� ��nh b�i Lam C�u",num=5}, {id="�� ��nh b�i Ti�u Ki�u Ki�u",num=1} }
--MisDescEnd
