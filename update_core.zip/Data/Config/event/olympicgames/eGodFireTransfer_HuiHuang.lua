--MisDescBegin
x808101_g_ScriptId	= 808101
x808101_g_Position_X=111.0545
x808101_g_Position_Z=211.7807
x808101_g_SceneID=0
x808101_g_AccomplishNPC_Name="Y�n Thanh"
x808101_g_MissionId			= 1007
x808101_g_MissionIdNext	= 1008
x808101_g_AcceptNPC_SceneID	=	24
x808101_g_Name 					= "�ao Nghi�u"
x808101_g_MissionKind			= 13
x808101_g_MissionLevel		= 10
x808101_g_IfMissionElite	= 0
x808101_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x808101_g_MissionName			= "Th�nh H�a huy ho�ng"
x808101_g_MissionInfo			= "#{XSHCD_20080418_026}"
x808101_g_MissionTarget		= "#{XSHCD_20080418_048}"
x808101_g_ContinueInfo		= "#{XSHCD_20080418_027}"
x808101_g_MissionComplete	= "#{XSHCD_20080418_028}"
x808101_g_MaxRound	= 3
x808101_g_ControlScript		= 001066
x808101_g_Custom	= { {id="�� giao Ho� C� cho L�c D߽ng Y�n Thanh",num=1} }
--MisDescEnd
