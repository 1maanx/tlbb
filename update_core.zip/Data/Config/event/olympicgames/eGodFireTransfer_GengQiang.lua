--MisDescBegin
x808104_g_ScriptId	= 808104
x808104_g_Position_X=242.5412
x808104_g_Position_Z=73.5041
x808104_g_SceneID=18
x808104_g_AccomplishNPC_Name="Ch�u V� U�"
x808104_g_MissionId			= 1010
x808104_g_MissionIdNext	= 1011
x808104_g_Name 					= "Ch�u V� U�"
x808104_g_MissionKind			= 13
x808104_g_MissionLevel		= 10
x808104_g_IfMissionElite	= 0
x808104_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x808104_g_MissionName			= "Th�nh h�a chuy�n ti�p m�nh h�n"
x808104_g_MissionInfo			= "#{XSHCD_20080418_035}"
x808104_g_MissionTarget		= "#{XSHCD_20080418_051}"
x808104_g_ContinueInfo		= "#{XSHCD_20080418_036}"
x808104_g_MissionComplete	= "#{XSHCD_20080418_037}"
x808104_g_MaxRound	= 3
x808104_g_ControlScript		= 001066
x808104_g_Custom	= { {id="�� ��nh b�i T�c C�u",num=5}, {id="�� ��nh b�i Ti�u T� T�",num=1} }
--MisDescEnd
