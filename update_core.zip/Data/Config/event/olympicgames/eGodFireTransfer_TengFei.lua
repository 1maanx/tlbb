--MisDescBegin
x808103_g_ScriptId	= 808103
x808103_g_Position_X=242.5412
x808103_g_Position_Z=73.5041
x808103_g_SceneID=18
x808103_g_AccomplishNPC_Name="Ch�u V� U�"
x808103_g_MissionId			= 1009
x808103_g_MissionIdNext	= 1010
x808103_g_AcceptNPC_SceneID	=	0
x808103_g_Name 					= "Y�n Thanh"
x808103_g_MissionKind			= 13
x808103_g_MissionLevel		= 10
x808103_g_IfMissionElite	= 0
x808103_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x808103_g_MissionName			= "Bay l�n c�ng Th�nh H�a"
x808103_g_MissionInfo			= "#{XSHCD_20080418_032}"
x808103_g_MissionTarget		= "#{XSHCD_20080418_050}"
x808103_g_ContinueInfo		= "#{XSHCD_20080418_033}"
x808103_g_MissionComplete	= "#{XSHCD_20080418_034}"
x808103_g_MaxRound	= 3
x808103_g_ControlScript		= 001066
x808103_g_Custom	= { {id="�� giao �u�c cho Nh�n Nam Ch�u V� U�",num=1} }
--MisDescEnd
