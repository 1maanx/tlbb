--MisDescBegin
x808095_g_ScriptId	= 808095
x808095_g_Position_X=164.5310
x808095_g_Position_Z=262.5004
x808095_g_SceneID=30
x808095_g_AccomplishNPC_Name="T� Phi"
x808095_g_MissionId			= 1001
x808095_g_MissionIdNext	= 1002
x808095_g_AcceptNPC_SceneID	=	1
x808095_g_Name 					= "Th�nh ho� ��n"
x808095_g_MissionKind			= 13
x808095_g_MissionLevel		= 10
x808095_g_IfMissionElite	= 0
x808095_g_IsMissionOkFail	= 0		--��������ĵ�0λ
x808095_g_MissionName			= "Th�p s�ng Th�nh H�a"
x808095_g_MissionInfo			= "#{XSHCD_20080418_008}"
x808095_g_MissionTarget		= "#{XSHCD_20080418_042}"
x808095_g_ContinueInfo		= "#{XSHCD_20080418_009}"
x808095_g_MissionComplete	= "#{XSHCD_20080418_010}"
x808095_g_MaxRound	= 3
x808095_g_ControlScript		= 001066
x808095_g_Custom	= { {id="�� giao �u�c cho T�y H� T� Phi",num=1} }
--MisDescEnd
