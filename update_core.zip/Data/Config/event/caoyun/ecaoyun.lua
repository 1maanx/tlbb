--MisDescBegin
x311010_g_MissionId = 4021
x311010_g_ScriptId = 311010
--MisDescEnd
