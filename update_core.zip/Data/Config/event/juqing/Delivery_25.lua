--MisDescBegin
x200092_g_ScriptId = 200092
x200092_g_MissionId = 25
x200092_g_PreMissionId = 24
x200092_g_Position_X=63
x200092_g_Position_Z=36
x200092_g_SceneID=2
x200092_g_AccomplishNPC_Name="�o�n Ch�nh Thu�n"
x200092_g_Name	="�o�n Ch�nh Thu�n"
x200092_g_MissionKind = 52
x200092_g_MissionLevel = 50
x200092_g_IfMissionElite = 0
x200092_g_MissionName="Nh�t B�n T�n Sa"
x200092_g_MissionInfo="#{Mis_juqing_0025}"
x200092_g_MissionTarget="#{Mis_juqing_Tar_0025}"
x200092_g_MissionComplete="  D� sao Ti�u Khang c�ng mu�n ng߽i t�i t�m ta... N�ng hi�n gi� ra sao? Ch�p m�t �� nhi�u n�m kh�ng g�p!"
x200092_g_MoneyBonus=10800
x200092_g_exp=120
x200092_g_Custom	= { {id="�� t�m ���c �o�n Ch�nh Thu�n",num=1} }
x200092_g_IsMissionOkFail = 0
--MisDescEnd
