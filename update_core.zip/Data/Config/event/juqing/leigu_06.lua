--MisDescBegin
x200045_g_ScriptId = 200045
x200045_g_MissionId = 37
x200045_g_PreMissionId = 36
x200045_g_Name = "T� Tinh H�"
x200045_g_IfMissionElite = 1
x200045_g_MissionLevel = 60
x200045_g_MissionKind = 53
x200045_g_MissionName="��ng c�a b�t tr�m"
x200045_g_MissionInfo="#{Mis_juqing_0037}"
x200045_g_MissionTarget="#{Mis_juqing_Tar_0037}"	--����Ŀ��
x200045_g_MissionContinue="  #{TM_20080313_08}"
x200045_g_MissionComplete="  #{TM_20080313_09}"	--�������npc˵���Ļ�
x200045_g_MoneyBonus=45000
x200045_g_exp=100000
x200045_g_RadioItemBonus={{id=10414016 ,num=1},{id=10415012,num=1},{id=10422011,num=1},{id=10423015,num=1}}
x200045_g_Custom	= { {id="�� ��nh b�i �inh Xu�n Thu",num=1} }
x200045_g_IsMissionOkFail = 0
--MisDescEnd
