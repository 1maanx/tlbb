--MisDescBegin
x200091_g_ScriptId = 200091
x200091_g_Position_X=230.2647
x200091_g_Position_Z=215.0359
x200091_g_SceneID=0
x200091_g_AccomplishNPC_Name="Khang M�n"
x200091_g_MissionId = 24
x200091_g_PreMissionId = 23
x200091_g_Name	="Khang M�n"
x200091_g_MissionKind = 52
x200091_g_MissionLevel = 50
x200091_g_IfMissionElite = 0
x200091_g_MissionName="B�o v� M� phu nh�n"
x200091_g_MissionInfo="#{Mis_juqing_0024}"
x200091_g_MissionTarget="#{Mis_juqing_Tar_0024}"
x200091_g_MissionComplete="  ��i hi�p �߶ng xa t�i, xin m�i v�o nh� u�ng tr�, ngh� ng�i"
x200091_g_MoneyBonus=7200
x200091_g_exp=9360
x200091_g_Custom	= { {id="�� t�m ���c Khang M�n",num=1} }
x200091_g_IsMissionOkFail = 0
--MisDescEnd
