--MisDescBegin
x200080_g_ScriptId = 200080
x200080_g_Position_X=62.9422
x200080_g_Position_Z=35.9417
x200080_g_SceneID=2
x200080_g_AccomplishNPC_Name="�o�n Ch�nh Thu�n"
x200080_g_MissionId = 1
x200080_g_PreMissionId = 3
x200080_g_Name	="�o�n Ch�nh Thu�n"
x200080_g_MissionKind = 51
x200080_g_MissionLevel = 20
x200080_g_IfMissionElite = 0
x200080_g_MissionName="��n nh� ai n�y s�ng"
x200080_g_MissionInfo="#{Mis_juqing_0001}"
x200080_g_MissionTarget="#{Mis_juqing_Tar_0001}"
x200080_g_MissionComplete="  $N, cu�i c�ng ng߽i �� t�i, ta t�m ng߽i qu� l�u"
x200080_g_MoneyBonus=10
x200080_g_exp=2800
x200080_g_Custom	= { {id="�� t�m ���c �o�n Ch�nh Thu�n",num=1} }
x200080_g_IsMissionOkFail = 0
--MisDescEnd
