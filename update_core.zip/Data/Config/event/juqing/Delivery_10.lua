--MisDescBegin
x200084_g_ScriptId = 200084
x200084_g_MissionId = 10
x200084_g_Position_X=81
x200084_g_Position_Z=266
x200084_g_SceneID=1
x200084_g_AccomplishNPC_Name="L�o C�"
x200084_g_PreMissionId = 9
x200084_g_Name	="V߽ng Ng� Y�n"
x200084_g_MissionKind = 48
x200084_g_MissionLevel = 30
x200084_g_IfMissionElite = 0
x200084_g_MissionName="Ho�n Th� Th�y C�c"
x200084_g_MissionInfo="#{Mis_juqing_0010}"
x200084_g_MissionTarget="#{Mis_juqing_Tar_0010}"
x200084_g_MissionComplete="  T� ra l� c�c h�, $N! Nh�t �nh l� do bi�u ca c�a ta nh� c�c h� t�i.."
x200084_g_MoneyBonus=4800
x200084_g_exp=4000
x200084_g_Custom	= { {id="�� t�m ���c V߽ng Ng� Y�n",num=1} }
x200084_g_IsMissionOkFail = 0
--MisDescEnd
