--MisDescBegin
x200086_g_ScriptId = 200086
x200086_g_Position_X=210.2844
x200086_g_Position_Z=201.6758
x200086_g_SceneID=0
x200086_g_AccomplishNPC_Name="T� Kinh L�i"
x200086_g_MissionId = 16
x200086_g_PreMissionId = 15
x200086_g_Name	="T� Kinh L�i"
x200086_g_MissionKind = 47
x200086_g_MissionLevel = 40
x200086_g_IfMissionElite = 0
x200086_g_MissionName="T� h�i l� nh�"
x200086_g_MissionInfo="#{Mis_juqing_0016}"
x200086_g_MissionTarget="#{Mis_juqing_Tar_0016}"
x200086_g_MissionComplete="  Hoan ngh�nh thi�u hi�p ��i danh, h�m nay nh�t ki�n qu� danh b�t h� truy�n. Th�t k�nh, th�t k�nh qu�"
x200086_g_MoneyBonus=6300
x200086_g_exp=5800
x200086_g_Custom	= { {id="�� t�m ���c T� Kinh L�i",num=1} }
x200086_g_IsMissionOkFail = 0
--MisDescEnd
