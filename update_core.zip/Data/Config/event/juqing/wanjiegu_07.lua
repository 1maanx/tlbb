--MisDescBegin
x200007_g_ScriptId = 200007
x200007_g_MissionId = 7
x200007_g_PreMissionId = 6
x200007_g_Name	="�o�n Ch�nh Thu�n"
x200007_g_Name1 ="�o�n Ch�nh Minh"
x200007_g_MissionKind = 51
x200007_g_MissionLevel = 20
x200007_g_IfMissionElite = 0
x200007_g_MissionName="��i ti�n qu�n"
x200007_g_MissionInfo="#{Mis_juqing_0007}"
x200007_g_MissionTarget="#{Mis_juqing_Tar_0007}"		
x200007_g_MissionContinue="  C�c h� t�m ta c� vi�c g�?"
x200007_g_MissionComplete="  Cu�i c�ng c�c ng߽i �� t�i"
x200007_g_MoneyBonus=1580
x200007_g_exp=12000
x200007_g_Custom	= { {id="�� h� t�ng �o�n Ch�nh Thu�n",num=1} }
--MisDescEnd
