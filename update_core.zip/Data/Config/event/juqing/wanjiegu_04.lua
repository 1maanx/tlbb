--MisDescBegin
x200004_g_ScriptId = 200004
x200004_g_MissionId = 4
x200004_g_PreMissionId = 3
x200004_g_Name	="�o�n Ch�nh Thu�n"
x200004_g_MissionKind = 51
x200004_g_MissionLevel = 20
x200004_g_IfMissionElite = 0
x200004_g_Position_X=62.9422
x200004_g_Position_Z=35.9417
x200004_g_SceneID=2
x200004_g_AccomplishNPC_Name="�o�n Ch�nh Thu�n"
x200004_g_MissionName="�c Qu�n M�n Doanh"
x200004_g_MissionInfo="#{Mis_juqing_0004}"
x200004_g_MissionTarget="#{Mis_juqing_Tar_0004}"
x200004_g_MissionComplete="  N�y, n�y, ta l�p t�c th�ng b�o vi�c n�y cho ho�ng huynh"
x200004_g_MoneyBonus=10
x200004_g_exp=6900
x200004_g_RadioItemBonus={{id=10414001 ,num=1},{id=10414002,num=1},{id=10414003,num=1},{id=10414004,num=1}}
x200004_g_Custom	= { {id="�� t�m ���c �o�n Ch�nh Thu�n",num=1} }
--MisDescEnd
