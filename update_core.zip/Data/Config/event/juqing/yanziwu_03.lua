--MisDescBegin
x200013_g_ScriptId = 200013
x200013_g_MissionId = 12
x200013_g_PreMissionId = 11
x200013_g_Position_X=129
x200013_g_Position_Z=77
x200013_g_SceneID=1
x200013_g_AccomplishNPC_Name="M� Dung Ph�c"
x200013_g_Name	="M� Dung Ph�c"
x200013_g_MissionKind = 48
x200013_g_MissionLevel = 30
x200013_g_IfMissionElite = 0
x200013_g_MissionName="��m d�i l�m m�ng"
x200013_g_MissionInfo="#{Mis_juqing_0012}"
x200013_g_MissionTarget="#{Mis_juqing_Tar_0012}"
x200013_g_MissionContinue="  C�c h� t�m ta c� vi�c g�?"
x200013_g_MissionComplete="  C� ph�i bi�u mu�i sai ng߽i mang th� t�i cho ta? H� v�n b�nh an v� s� ch�? Ь ta xem th� tr߾c"
x200013_g_MoneyBonus=8100
x200013_g_exp=8000
x200013_g_DemandItem={{id=40001004,num=1}}
x200013_g_IsMissionOkFail = 0
--MisDescEnd
