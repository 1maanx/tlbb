--MisDescBegin
x200085_g_ScriptId = 200085
x200085_g_MissionId = 13
x200085_g_PreMissionId = 12
x200085_g_Name	="V߽ng Ng� Y�n"
x200085_g_MissionKind = 48
x200085_g_MissionLevel = 30
x200085_g_IfMissionElite = 0
x200085_g_Position_X=81
x200085_g_Position_Z=266
x200085_g_SceneID=1
x200085_g_AccomplishNPC_Name="L�o C�"
x200085_g_MissionName="Nh�t ph�m �߶ng "
x200085_g_MissionInfo="#{Mis_juqing_0013}"
x200085_g_MissionTarget="#{Mis_juqing_Tar_0013}"
x200085_g_MissionComplete="  $N, cu�i c�ng ng߽i �� c�u ch�ng ta"
x200085_g_MoneyBonus=8100
x200085_g_exp=8000
x200085_g_Custom	= { {id="�� t�m ���c V߽ng Ng� Y�n",num=1} }
x200085_g_IsMissionOkFail = 0
--MisDescEnd
