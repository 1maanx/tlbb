--MisDescBegin
x200020_g_ScriptId = 200020
x200020_g_CopySceneName="T� Hi�n Trang "
--MisDescEnd
