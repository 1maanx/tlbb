--MisDescBegin
x200094_g_ScriptId = 200094
x200094_g_Position_X=125.5508
x200094_g_Position_Z=144.8913
x200094_g_SceneID=14
x200094_g_AccomplishNPC_Name="T� Tinh H�"
x200094_g_MissionId = 33
x200094_g_PreMissionId = 32
x200094_g_Name	="T� Tinh H�"
x200094_g_MissionKind = 53
x200094_g_MissionLevel = 60
x200094_g_IfMissionElite = 0
x200094_g_MissionName="Tr�n Long k� h�i"
x200094_g_MissionInfo="#{Mis_juqing_0033}"
x200094_g_MissionTarget="#{Mis_juqing_Tar_0033}"
x200094_g_MissionComplete="  T� l�u �� nghe danh ��i hi�p$N, h�m nay nh�t ki�n qu� th�t ngh�a b�t phi ph�m, ��ng l� Tr߶ng Giang s�ng sau x� s�ng tr߾c"
x200094_g_MoneyBonus=18000
x200094_g_exp=37500
x200094_g_Custom	= { {id="�� t�m ���c T� Tinh H�",num=1} }
x200094_g_IsMissionOkFail = 0
--MisDescEnd
