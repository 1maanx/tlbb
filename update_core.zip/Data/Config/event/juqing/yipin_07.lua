--MisDescBegin
x200056_g_ScriptId = 200056
x200056_g_MissionId = 45
x200056_g_PreMissionId = 44
x200056_g_Name	="H� Tr�c"
x200056_g_Name1 = "L� Thanh L�"
x200056_g_MissionKind = 49
x200056_g_MissionLevel = 70
x200056_g_IfMissionElite = 0
x200056_g_MissionName="Su�t �i c� huynh"
x200056_g_MissionInfo="#{Mis_juqing_0045}"
x200056_g_MissionTarget="#{Mis_juqing_Tar_0045}"		
x200056_g_MissionComplete="  C�m �n huynh, $N. Mu�i v� M�ng Lang sau n�y s� s�ng h�nh ph�c � ��y"		
x200056_g_MoneyBonus=48600
x200056_g_exp=86400
x200056_g_RadioItemBonus={{id=10423016 ,num=1},{id=10423017,num=1},{id=10423018,num=1},{id=10423019,num=1}}
x200056_g_Custom	= { {id="�� h� t�ng H� Tr�c",num=1} }
--MisDescEnd
