--MisDescBegin
x200093_g_ScriptId = 200093
x200093_g_MissionId = 26
x200093_g_PreMissionId = 25
x200093_g_Position_X=128
x200093_g_Position_Z=50
x200093_g_SceneID=18
x200093_g_AccomplishNPC_Name="Gia Lu�t M�c Ca"
x200093_g_Name	="Ti�u Phong"
x200093_g_MissionKind = 52
x200093_g_MissionLevel = 50
x200093_g_IfMissionElite = 0
x200093_g_MissionName="T�i n�i Th߽ng Mang"
x200093_g_MissionInfo="#{Mis_juqing_0026}"
x200093_g_MissionTarget="#{Mis_juqing_Tar_0026}"
x200093_g_MissionComplete="  $N, ng�n gi� n�o th�i ng߽i t�i ��y? ��ng l� nh� ca ca ph�i kh�ng?"
x200093_g_MoneyBonus=23400
x200093_g_exp=31920
x200093_g_Custom	= { {id="�� t�m ���c Ti�u Phong",num=1} }
x200093_g_IsMissionOkFail = 0
--MisDescEnd
