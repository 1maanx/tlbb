--MisDescBegin
x200053_g_ScriptId = 200053
x200053_g_MissionId = 43
x200053_g_PreMissionId = 42
x200053_g_Name = "Hi�u L�i"
x200053_g_IfMissionElite = 1
x200053_g_MissionLevel = 70
x200053_g_MissionKind = 49
x200053_g_MissionName="B�y ti�c r��u h�i Qu�n Tam Ng�"
x200053_g_MissionInfo="#{Mis_juqing_0043}"
x200053_g_MissionTarget="#{Mis_juqing_Tar_0043}"	--����Ŀ��
x200053_g_MissionComplete="  Huynh kh�ng ph�i l� $N sao? C�ng ch�a ch�ng ta lu�n nh�c t�i huynh. Mau ng�i �i"
x200053_g_MoneyBonus=48600
x200053_g_exp=86400
x200053_g_RadioItemBonus={{id=10414017 ,num=1},{id=10414018,num=1},{id=10414019,num=1}}
x200053_g_Custom	= { {id="�� t�m ���c Hi�u L�i",num=1} }
--MisDescEnd
