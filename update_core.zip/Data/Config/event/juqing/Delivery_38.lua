--MisDescBegin
x200095_g_ScriptId = 200095
x200095_g_Position_X=113.5541
x200095_g_Position_Z=63.7330
x200095_g_SceneID=0
x200095_g_AccomplishNPC_Name="H�ch Li�n Thi�t Th�"
x200095_g_MissionId = 38
x200095_g_PreMissionId = 37
x200095_g_Name	="H�ch Li�n Thi�t Th�"
x200095_g_MissionKind = 49
x200095_g_MissionLevel = 70
x200095_g_IfMissionElite = 0
x200095_g_MissionName="#{MISSIONNAME_JUQING_1}"
x200095_g_MissionInfo="#{Mis_juqing_0038}"
x200095_g_MissionTarget="#{Mis_juqing_Tar_0038}"
x200095_g_MissionComplete="  #{TM_20080313_05}"
x200095_g_MoneyBonus=10800
x200095_g_exp=21600
x200095_g_Custom	= { {id="�� t�m ���c Li�n Thi�t Th�",num=1} }
x200095_g_IsMissionOkFail = 0
--MisDescEnd
