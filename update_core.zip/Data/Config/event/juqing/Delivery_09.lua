--MisDescBegin
x200083_g_ScriptId = 200083
x200083_g_Position_X=128.5046
x200083_g_Position_Z=74.7418
x200083_g_SceneID=1
x200083_g_AccomplishNPC_Name="A B�ch"
x200083_g_MissionId = 9
x200083_g_PreMissionId = 8
x200083_g_Name	="A B�ch"
x200083_g_MissionKind = 48
x200083_g_MissionLevel = 30
x200083_g_IfMissionElite = 0
x200083_g_MissionName="C� T� M� Dung"
x200083_g_MissionInfo="#{Mis_juqing_0009}"
x200083_g_MissionTarget="#{Mis_juqing_Tar_0009}"
x200083_g_MissionComplete="  $N, cu�i c�ng ng߽i �� t�i, ta t�m ng߽i qu� l�u"
x200083_g_MoneyBonus=4800
x200083_g_exp=4800
x200083_g_Custom	= { {id="�� t�m ���c A B�ch",num=1} }
x200083_g_IsMissionOkFail = 0
--MisDescEnd
