--MisDescBegin
x200014_g_ScriptId = 200014
x200014_g_CopySceneName="Y�n T� � "
--MisDescEnd
