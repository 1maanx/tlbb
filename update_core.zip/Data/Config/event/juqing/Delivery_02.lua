--MisDescBegin
x200081_g_ScriptId = 200081
x200081_g_MissionId = 2
x200081_g_PreMissionId = 1
x200081_g_Name	="Chung Linh"
x200081_g_Position_X=74
x200081_g_Position_Z=50
x200081_g_SceneID=2
x200081_g_AccomplishNPC_Name="Hoa H�ch C�n"
x200081_g_MissionKind = 51
x200081_g_MissionLevel = 20
x200081_g_IfMissionElite = 0
x200081_g_MissionName="�o xanh l�i l�c h�nh n�i hi�m"
x200081_g_MissionInfo="#{Mis_juqing_0002}"
x200081_g_MissionTarget="#{Mis_juqing_Tar_0002}"
x200081_g_MissionComplete="    A, ng߽i ch�ng ph�i l� $N �� sao? Ng߽i t�i t�m ng߶i anh em �o�n D�?"
x200081_g_MoneyBonus=10
x200081_g_exp=6900
x200081_g_Custom	= { {id="�� t�m ���c Chung Linh",num=1} }
x200081_g_IsMissionOkFail = 0
--MisDescEnd
