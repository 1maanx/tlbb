--MisDescBegin
x200041_g_ScriptId = 200041
x200041_g_MissionId = 34
x200041_g_PreMissionId = 33
x200041_g_Position_X=152
x200041_g_Position_Z=153
x200041_g_SceneID=14
x200041_g_AccomplishNPC_Name="Ph�m B�ch Linh"
x200041_g_Name = "T� Tinh H�"
x200041_g_IfMissionElite = 1
x200041_g_MissionLevel = 60
x200041_g_MissionKind = 53
x200041_g_MissionName="T�nh h�u qu� �m"
x200041_g_MissionInfo="#{Mis_juqing_0034}"
x200041_g_MissionTarget="#{Mis_juqing_Tar_0034}"
x200041_g_MissionComplete="  T�i h� cung h�u �� l�u r�i, m�i ��i hi�p ng�i v�o c�"
x200041_g_MoneyBonus=7200
x200041_g_exp=17000
x200041_g_RadioItemBonus={{id=10415008 ,num=1},{id=10415009,num=1},{id=10415010,num=1},{id=10415011,num=1}}
x200041_g_Custom	= { {id="�� t�m ���c T� Tinh H�",num=1} }
--MisDescEnd
