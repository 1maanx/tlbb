--MisDescBegin
x200051_g_ScriptId = 200051
x200051_g_MissionId = 41
x200051_g_PreMissionId = 40
x200051_g_Name = "H� Tr�c"
x200051_g_IfMissionElite = 1
x200051_g_MissionLevel = 70
x200051_g_MissionKind = 49
x200051_g_MissionName="Y ti�u nh�n gian v�n s�"
x200051_g_MissionInfo="#{Mis_juqing_0041}"
x200051_g_MissionTarget="#{Mis_juqing_Tar_0041}"	--����Ŀ��
x200051_g_MissionComplete="  Ch�ng ta mau r�i kh�i ��y, A di �� Ph�t, �c t�i �c t�i.."
x200051_g_MoneyBonus=9000
x200051_g_exp=17280
x200051_g_RadioItemBonus={{id=10415013 ,num=1},{id=10415014,num=1},{id=10415015,num=1}}
x200051_g_Custom	= { {id="Y ti�u nh�n gian v�n s�",num=1} }
--MisDescEnd
