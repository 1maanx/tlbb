--MisDescBegin
x200088_g_ScriptId = 200088
x200088_g_MissionId = 18
x200088_g_PreMissionId = 17
x200088_g_Name	="T� Kinh L�i"
x200088_g_MissionKind = 47
x200088_g_MissionLevel = 40
x200088_g_Position_X=210.2844
x200088_g_Position_Z=201.6758
x200088_g_SceneID=0
x200088_g_AccomplishNPC_Name="T� Kinh L�i"
x200088_g_IfMissionElite = 0
x200088_g_MissionName="C�ng ti�n, c�ng l�i"
x200088_g_MissionInfo="#{Mis_juqing_0018}"
x200088_g_MissionTarget="#{Mis_juqing_Tar_0018}"
x200088_g_MissionComplete="  Th�t kh�ng ng� Ch�n Nam V߽ng l�i kh�ng m�ng �n ��i ngh�a d�n t�c, th�t khi�n ng߶i ta �au l�ng"
x200088_g_MoneyBonus=5400
x200088_g_exp=5400
x200088_g_Custom	= { {id="�� t�m ���c T� Kinh L�i",num=1} }
x200088_g_IsMissionOkFail = 0
--MisDescEnd
